//
//  SPCanvas.h
//  SharePaint
//
//  Created by Akira Suzuki on 10/02/23.
//  Copyright 2010 Akira Suzuki. All rights reserved.
//

#import <map>
#import <vector>
#import <string>
#import <UIKit/UIKit.h>
#import "PenProperties.h"
#import "SPStroke.h"
#import "StrokeSyncAgent.h"

@interface SPCanvas : UIView {
 @public
  int last_x, last_y, width, height;
  bool on_stroke;
  PenProperties pen_properties;
  std::map<std::pair<long long, long long>, SPStroke> strokes_history;
  std::vector<int> x_array, y_array;
  std::string user_nickname;
  std::string canvas_id, user_id;
  long long InitServerTime;
  StrokeSyncAgent sync_agent;
  unsigned int layer_index;
  unsigned int *stroke_bitmap, *display_bitmap, *prev_bitmap;
  unsigned int *layer_bitmap[SPLayerNumber];
  
  IBOutlet UISegmentedControl* draw_mode_button;
  IBOutlet UIView* spuit_view;
}

- (void)setup;
- (void)clear_canvas;
- (void)touchPressedAtX:(int)x y:(int)y;
- (void)touchDraggedAtX:(int)x y:(int)y;
- (void)touchReleasedAtX:(int)x y:(int)y;
- (void)drawLineFromX:(int)x0 y:(int)y0 toX:(int)x1 y:(int)y1;
- (void)drawStroke:(unsigned int*)bitmap with:(SPStroke)stroke;
- (IBAction)undoOneStroke:(id)sender;
- (std::string)canvasID;
- (std::string)userID;
- (void)get_response:(NSNotification*)notification;
- (void)redrawStrokes:(unsigned int*[])bitmaps;
- (void)composeBitmap:(unsigned int*)s_bitmap with:(unsigned int*)w_bitmap alpha:(CGFloat)density to:(unsigned int*)d_bitmap inRect:(CGRect)rect;
- (void)applyWithStrokeBitmap:(unsigned int*)s_bitmap to:(unsigned int*)d_bitmap alpha:(CGFloat)density;
- (UIImage*)clipImageOfBitmap:(unsigned int*)bitmap inRect:(CGRect)rect;
- (void)composeAllLayers:(unsigned int*[])bitmaps to:(unsigned int*)bitmap inRect:(CGRect)rect;
- (void)setLayerIndex:(unsigned int)index;
- (void)spuitAtX:(int)x y:(int)y;
- (void)spuitEnded;

@end
