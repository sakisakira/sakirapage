//
//  SharePaintViewController.h
//  SharePaint
//
//  Created by Akira Suzuki on 10/02/23.
//  Copyright Akira Suzuki 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SharePaintViewController : UIViewController {
  IBOutlet UIViewController* penpropviewcontroller;
  IBOutlet UISegmentedControl* pen_color_btns;
  IBOutlet UISlider* pen_width_slider;
  IBOutlet UISlider* pen_density_slider;
  IBOutlet UISegmentedControl* layer_btns;
  IBOutlet UIViewController* hsbcolorpickercontroller;
  IBOutlet UISlider* hue_slider;
  IBOutlet UIButton* pendlgcolbox;
  IBOutlet UIView* penhsbcolbox;
}

- (IBAction)showPenPropDialog:(id)sender;
- (void)setColorButton:(int)col;
- (IBAction)applyPenPropDialog:(id)sender;
- (IBAction)dismissPenPropDialog:(id)sender;
- (IBAction)showHSBColorPicker:(id)sender;
- (IBAction)dismissHSBColorPicker:(id)sender;
- (IBAction)applyHSBColorPicker:(id)sender;
- (void)setColorBoxes;
- (IBAction)penRadioButtonPressed:(id)sender;

@end

