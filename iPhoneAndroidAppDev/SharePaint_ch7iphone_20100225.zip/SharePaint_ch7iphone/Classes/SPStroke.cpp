/*
 *  SPStroke.cpp
 *  SharePaint
 *
 *  Created by Akira Suzuki on 10/02/23.
 *  Copyright 2010 Akira Suzuki. All rights reserved.
 *
 */

#import <sstream>
#import "SPStroke.h"

SPStroke::SPStroke(void) {
  setup_variables();
}

SPStroke::SPStroke(std::string str) {
  setup_variables();
  bool before_points = true;
  unsigned int is, ic;
  std::string keyval, key, val;
  while (!str.empty()) {
    is = str.find(" ");
    if (is != std::string::npos) {
      keyval = str.substr(0, is);
      str.erase(0, is + 1);
    } else {
      keyval = str;
      str = "";
    }
    
    if (keyval == "points:") {
      before_points = false;
      continue;
    }
    
    if (before_points) {
      ic = keyval.find(":");
      key = keyval.substr(0, ic);
      val = keyval.substr(ic + 1);
      if (key == "client_time") {
        std::istringstream istr(val);
        istr >> this->client_time;
      } else if (key == "server_time") {
        std::istringstream istr(val);
        istr >> this->server_time;
      } else if (key == "pen_properties") {
        this->pen_properties = PenProperties(val);
      } else if (key == "layer") {
        std::istringstream istr(val);
        istr >> this->layer;
      } else if (key == "user_name") {
        this->user_name = val;
      }
    } else {
      int x, y;
      char d;
      std::istringstream istr(keyval);
      istr >> x >> d >> y;
      this->x_array.push_back(x);
      this->y_array.push_back(y);
    }
  }
}

void SPStroke::setup_variables(void) {
  client_time = server_time = layer = 0;
  user_name = "";
}

std::string SPStroke::toString(void) {
	std::ostringstream strs;
	
	strs << " client_time:" << client_time
	<< " server_time:" << server_time
  << " user_name:" << user_name
	<< " pen_properties:" << pen_properties.toString()
	<< " layer:" << layer;
	
	strs << " points:";
	for (int i = 0; i < x_array.size(); i ++)
		strs << " " << x_array[i]
		<< "-" << y_array[i];
	
	return strs.str();
}

