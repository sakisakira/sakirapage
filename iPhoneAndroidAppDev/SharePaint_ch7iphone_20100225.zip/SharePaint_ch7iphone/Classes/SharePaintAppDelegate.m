//
//  SharePaintAppDelegate.m
//  SharePaint
//
//  Created by Akira Suzuki on 10/02/23.
//  Copyright Akira Suzuki 2010. All rights reserved.
//

#import "SharePaintAppDelegate.h"
#import "SharePaintViewController.h"

@implementation SharePaintAppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
