//
//  SPCanvas.mm
//  SharePaint
//
//  Created by Akira Suzuki on 10/02/23.
//  Copyright 2010 Akira Suzuki. All rights reserved.
//

#import "SPCanvas.h"
#import "algorithm"


@implementation SPCanvas


- (id)initWithCoder:(NSCoder *)decoder {
  if (self = [super initWithCoder:decoder]) {
    self->bitmap_data = NULL;
    [self setup];
  }
  return self;
}

- (void)setup {
  self->on_stroke = false;
  self->pen_properties = PenProperties();
  self->bitmap_data = NULL;
  self->width = 320;
  self->height = 480;
  self->user_nickname = "iphone";
  self->canvas_id = "";
  self->user_id = "";
  self->InitServerTime = (long long)10000 * 365 * 24 * 60 * 60 * 1000;
  [self clear_canvas];
}

- (void)clear_canvas {
  if (self->bitmap_data)
    delete[] bitmap_data;
  
  int length = self->width * self->height;
  self->bitmap_data = new unsigned int[length];
  for (int i = 0; i < length; i ++)
    self->bitmap_data[i] = 0xffffffff;

  [self setNeedsDisplay];
  
  self->sync_agent.canvas = self;
  [[NSNotificationCenter defaultCenter]
   addObserver:self 
   selector:@selector(get_response:)
   name:@"SPServerResponseGot"
   object:self->sync_agent.delegate];
  SPStroke stroke;
  stroke.user_name = [self userID];
  stroke.client_time = (long long)([[NSDate date] 
                                    timeIntervalSince1970] * 1000.0);
  self->sync_agent.append_stroke(stroke);
  self->sync_agent.get_strokes();
}


- (void)drawRect:(CGRect)rect {
  CGDataProviderRef providerref =
    CGDataProviderCreateWithData(NULL, self->bitmap_data + ((int)(rect.origin.y) * self->width + (int)(rect.origin.x)), rect.size.width * rect.size.height * 4, NULL);
  CGColorSpaceRef colorspace = CGColorSpaceCreateDeviceRGB();
  CGImageRef imgref =
  CGImageCreate(rect.size.width, rect.size.height, 8, 32, self->width * 4, colorspace, kCGImageAlphaPremultipliedFirst, providerref, NULL, NO, kCGRenderingIntentDefault);
  CGColorSpaceRelease(colorspace);
  CGDataProviderRelease(providerref);
  UIImage *img = [[UIImage alloc] initWithCGImage:imgref];
  [img drawInRect:rect];
  [img release];
  CGImageRelease(imgref);
}


- (void)dealloc {
  if (self->bitmap_data)
    delete[] self->bitmap_data;
  [super dealloc];
}

- (void)touchPressedAtX:(int)x y:(int)y {
  self->last_x = x;
  self->last_y = y;
  self->on_stroke = true;
  self->x_array.clear();
  self->y_array.clear();
  self->x_array.push_back(x);
  self->y_array.push_back(y);
}

- (void)touchDraggedAtX:(int)x y:(int)y {
  [self drawLineFromX:self->last_x y:self->last_y toX:x y:y];
  
  int pen_width_half = self->pen_properties.width / 2 + 1;
  int min_x = std::min(x, self->last_x) - pen_width_half;
  int max_x = std::max(x, self->last_x) + pen_width_half;
  int min_y = std::min(y, self->last_y) - pen_width_half;
  int max_y = std::max(y, self->last_y) + pen_width_half;
  [self setNeedsDisplayInRect:CGRectMake(min_x, min_y, max_x - min_x + 1, max_y - min_y + 1)];
  self->last_x = x;
  self->last_y = y;
  self->x_array.push_back(x);
  self->y_array.push_back(y);
}

- (void)touchReleasedAtX:(int)x y:(int)y {
  SPStroke stroke;
  stroke.user_name = [self userID];
  stroke.client_time = (long long)([[NSDate date] timeIntervalSince1970] * 1000);
  stroke.pen_properties = self->pen_properties;
  stroke.x_array = self->x_array;
  stroke.y_array = self->y_array;
 
  std::pair<long long, long long> times;
  times.first = InitServerTime;
  times.second = stroke.client_time;
  strokes_history[times] = stroke;

  self->on_stroke = false;
 
  [self get_response:nil];
  self->sync_agent.append_stroke(stroke);
}

- (void)drawLineFromX:(int)x0 y:(int)y0 toX:(int)x1 y:(int)y1 {
  CGColorSpaceRef colorspace = CGColorSpaceCreateDeviceRGB();
  CGContextRef context =
  CGBitmapContextCreate(self->bitmap_data, self->width, self->height, 8, self->width * 4, colorspace, kCGImageAlphaPremultipliedFirst);
  CGAffineTransform ctm = CGAffineTransformMakeScale(1, -1);
  ctm = CGAffineTransformTranslate(ctm, 0, - self->height);
  CGContextConcatCTM(context, ctm);
  
  CGContextSetLineCap(context, kCGLineCapRound);
  int pen_color = self->pen_properties.color;
  CGFloat components[4];
  components[0] = (pen_color & 0x00ff0000) / (255.0 * 0x10000);
  components[1] = (pen_color & 0x0000ff00) / (255.0 * 0x100);
  components[2] = (pen_color & 0x000000ff) / 255.0;
  components[3] = (pen_color & 0xff000000) / (255.0 * 0x1000000);
  CGColorRef color = CGColorCreate(colorspace, components);
  CGContextSetStrokeColorWithColor(context, color);
  CGContextSetLineWidth(context, self->pen_properties.width);
  
  CGContextMoveToPoint(context, x0, y0);
  CGContextAddLineToPoint(context, x1, y1);
  CGContextDrawPath(context, kCGPathStroke);
  
  CGColorSpaceRelease(colorspace);
  CGColorRelease(color);
  CGContextRelease(context);
}

- (void)drawStroke:(unsigned int*)bitmap with:(SPStroke)stroke {
  CGColorSpaceRef colorspace = CGColorSpaceCreateDeviceRGB();
  CGContextRef context =
  CGBitmapContextCreate(bitmap, self->width, self->height, 8, self->width * 4, colorspace, kCGImageAlphaPremultipliedFirst);
  CGAffineTransform ctm = CGAffineTransformMakeScale(1, -1);
  ctm = CGAffineTransformTranslate(ctm, 0, - self->height);
  CGContextConcatCTM(context, ctm);
  CGContextSetLineCap(context, kCGLineCapRound);
  CGContextSetLineJoin(context, kCGLineJoinRound);
  
  int pen_color = stroke.pen_properties.color;
  CGFloat components[4];
  components[0] = (pen_color & 0x00ff0000) / (255.0 * 0x10000);
  components[1] = (pen_color & 0x0000ff00) / (255.0 * 0x100);
  components[2] = (pen_color & 0x000000ff) / 255.0;
  components[3] = (pen_color & 0xff000000) / (255.0 * 0x1000000);
  CGColorRef color = CGColorCreate(colorspace, components);
  CGContextSetStrokeColorWithColor(context, color);
  CGContextSetLineWidth(context, stroke.pen_properties.width);
  
  CGContextMoveToPoint(context, stroke.x_array[0], stroke.y_array[0]);
  for (int i = 1; i < stroke.x_array.size(); i ++)
    CGContextAddLineToPoint(context, stroke.x_array[i], stroke.y_array[i]);
  CGContextDrawPath(context, kCGPathStroke);
  
  CGColorSpaceRelease(colorspace);
  CGColorRelease(color);
  CGContextRelease(context);
}

- (IBAction)undoOneStroke:(id)sender {
  if (self->strokes_history.empty()) return;
  
    // 自分自身の最後のストロークを検索
  std::map<std::pair<long long, long long>, SPStroke>::iterator it;
  it = self->strokes_history.end();
  do {
    it --;
    if (it->second.user_name == [self userID]) {  // もし見付かれば
      self->sync_agent.delete_stroke(it->second); // サーバへ報告
      self->strokes_history.erase(it);  // そのストロークを削除
      [self redrawStrokes:self->bitmap_data];  // 描画しなおして
      return;  // 帰る
    }
  } while (it != self->strokes_history.begin());
}

- (std::string)canvasID {
  self->canvas_id = "testuser@19700101000000000";  // デバッグ用!!
  if (self->canvas_id == "") {
    NSDateFormatter *formatter = [[[NSDateFormatter alloc] init] autorelease];
    [formatter setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"GMT"]];
    [formatter setDateFormat:@"yyyyMMddHHmmssSSS"];
    NSString* nowstr = [formatter stringFromDate:[NSDate date]];
    std::string nowstr_([nowstr UTF8String]);
    self->canvas_id = self->user_nickname + "@" + nowstr_;
  }
  return self->canvas_id;
}

- (std::string)userID {
  if (self->user_id == "") {
    NSDateFormatter *formatter = [[[NSDateFormatter alloc] init] autorelease];
    [formatter setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"GMT"]];
    [formatter setDateFormat:@"yyyyMMddHHmmssSSS"];
    NSString* nowstr = [formatter stringFromDate:[NSDate date]];
    std::string nowstr_([nowstr UTF8String]);
    self->user_id = self->user_nickname + "@" + nowstr_;
  }
  return self->user_id;
}

- (void)redrawStrokes:(unsigned int*)bitmap {
  for (int i = 0; i < self->width * self->height; i ++)
    bitmap[i] = 0xffffffff;
  
  std::map<std::pair<long long, long long>, SPStroke>::iterator it
  = self->strokes_history.begin();
  while (it != self->strokes_history.end())
    [self drawStroke:bitmap with:(*(it ++)).second];
  
  [self setNeedsDisplay];
}

- (void)get_response:(NSNotification*)notification {
  bool should_be_refresh = false;
  std::vector<SPStroke>::iterator it;
  
  @synchronized (self->sync_agent.delegate) {
    switch (self->sync_agent.get_response()) {
      case StrokeSyncAgent::Strokes:
        it = self->sync_agent.returned_strokes.begin();
        while (it != self->sync_agent.returned_strokes.end()) {
          if ((*it).user_name == [self userID]) {
            std::pair<long long, long long> otimes;
            otimes.first = self->InitServerTime;
            otimes.second = (*it).client_time;
            self->strokes_history.erase(otimes);
          } else {
            should_be_refresh = true;
          }
          std::pair<long long, long long> ntimes;
          ntimes.first = it->server_time;
          ntimes.second = it->client_time;
          self->strokes_history[ntimes] = *it;
          it ++;
        }
        self->sync_agent.returned_strokes.clear();  // フラグをクリア
        if (should_be_refresh)
          [self redrawStrokes:self->bitmap_data];
        break;
      case StrokeSyncAgent::Refresh:
        self->sync_agent.canvas_should_be_refreshed = false;  // フラグをクリア
        self->strokes_history.clear();
        self->sync_agent.get_strokes_sync();
    }
  }
}


@end
