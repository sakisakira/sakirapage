//
//  SharePaintViewController.m
//  SharePaint
//
//  Created by Akira Suzuki on 10/02/23.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import "SharePaintViewController.h"
#import "SPCanvas.h"

@implementation SharePaintViewController



/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
  SPCanvas* canvas = (SPCanvas*)self.view;
  if (canvas->bitmap_data == NULL) return;
  UITouch *touch = [touches anyObject];
  if (touch) {
    CGPoint pt = [touch locationInView:canvas];
    [canvas touchPressedAtX:pt.x y:pt.y];
  }
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
  SPCanvas* canvas = (SPCanvas*)self.view;
  if (canvas->bitmap_data == NULL) return;
  UITouch *touch = [touches anyObject];
  if (touch) {
    CGPoint pt = [touch locationInView:canvas];
    [canvas touchDraggedAtX:pt.x y:pt.y];
  }
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
  SPCanvas* canvas = (SPCanvas*)self.view;
  if (canvas->bitmap_data == NULL) return;
  UITouch *touch = [touches anyObject];
  if (touch) {
    CGPoint pt = [touch locationInView:canvas];
    [canvas touchReleasedAtX:pt.x y:pt.y];
  }
}

- (IBAction)showPenPropDialog:(id)sender {
  SPCanvas* canvas = (SPCanvas*)self.view;
  [self setColorButton:canvas->pen_properties.color];
  self->pen_width_slider.minimumValue = 1;
  self->pen_width_slider.maximumValue = 25;
  self->pen_width_slider.value = canvas->pen_properties.width;
  [self presentModalViewController:penpropviewcontroller animated:YES];
}

- (void)setColorButton:(int)col {
  if (col == 0xff000000)
    pen_color_btns.selectedSegmentIndex = 0;
  else if (col == 0xffff0000)
    pen_color_btns.selectedSegmentIndex = 2;
  else if (col == 0xff00ff00)
    pen_color_btns.selectedSegmentIndex = 3;
  else if (col == 0xff0000ff)
    pen_color_btns.selectedSegmentIndex = 4;
  else 
    pen_color_btns.selectedSegmentIndex = 1;
}

- (IBAction)applyPenPropDialog:(id)sender {
  SPCanvas* canvas = (SPCanvas*)self.view;
  int col;
  switch (self->pen_color_btns.selectedSegmentIndex) {
    case 0:
      col = 0xff000000;
      break;
    case 1:
      col = 0xffffffff;
      break;
    case 2:
      col = 0xffff0000;
      break;
    case 3:
      col = 0xff00ff00;
      break;
    case 4:
      col = 0xff0000ff;
      break;
    default:
      break;
  }
  canvas->pen_properties.color = col;
  canvas->pen_properties.width = (int)self->pen_width_slider.value;
  [self dismissModalViewControllerAnimated:YES];
}
- (IBAction)dismissPenPropDialog:(id)sender {
  [self dismissModalViewControllerAnimated:YES];
}


@end
