/*
 *  PenProperties.cpp
 *  SharePaint
 *
 *  Created by Akira Suzuki on 10/02/23.
 *  Copyright 2010 Akira Suzuki. All rights reserved.
 *
 */

#include "PenProperties.h"

PenProperties::PenProperties(int c, int w, int d) {
  this->color = c;
  this->width = w;
  this->density = d;
}

PenProperties::PenProperties(void) {
  this->color = 0xff000000;
  this->width = 3;
  this->density = 128;
}
