/*
 *  PenProperties.h
 *  SharePaint
 *
 *  Created by Akira Suzuki on 10/02/23.
 *  Copyright 2010 Akira Suzuki. All rights reserved.
 *
 */

class PenProperties {
  public:
  int color, width, density;

  PenProperties(int c, int w, int d);
  PenProperties(void);
};
