//
//  SPCanvas.h
//  SharePaint
//
//  Created by Akira Suzuki on 10/02/23.
//  Copyright 2010 Akira Suzuki. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PenProperties.h"


@interface SPCanvas : UIView {
 @public
  int last_x, last_y, width, height;
  bool on_stroke;
  PenProperties pen_properties;
  unsigned int *bitmap_data;
}

- (void)setup;
- (void)clear_canvas;
- (void)touchPressedAtX:(int)x y:(int)y;
- (void)touchDraggedAtX:(int)x y:(int)y;
- (void)touchReleasedAtX:(int)x y:(int)y;
- (void)drawLineFromX:(int)x y:(int)y toX:(int)x y:(int)y;

@end
