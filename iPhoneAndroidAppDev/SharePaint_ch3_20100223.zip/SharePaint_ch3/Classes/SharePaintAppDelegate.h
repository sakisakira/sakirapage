//
//  SharePaintAppDelegate.h
//  SharePaint
//
//  Created by Akira Suzuki on 10/02/23.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SharePaintViewController;

@interface SharePaintAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    SharePaintViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet SharePaintViewController *viewController;

@end

