//
//  SPCanvas.h
//  SharePaint
//
//  Created by Akira Suzuki on 10/02/23.
//  Copyright 2010 Akira Suzuki. All rights reserved.
//

#import <map>
#import <vector>
#import <UIKit/UIKit.h>
#import "PenProperties.h"
#import "SPStroke.h"

@interface SPCanvas : UIView {
 @public
  int last_x, last_y, width, height;
  bool on_stroke;
  PenProperties pen_properties;
  unsigned int *bitmap_data;
  std::map<long long, SPStroke> strokes_history;
  std::vector<int> x_array, y_array;
}

- (void)setup;
- (void)clear_canvas;
- (void)touchPressedAtX:(int)x y:(int)y;
- (void)touchDraggedAtX:(int)x y:(int)y;
- (void)touchReleasedAtX:(int)x y:(int)y;
- (void)drawLineFromX:(int)x0 y:(int)y0 toX:(int)x1 y:(int)y1;
- (void)drawStroke:(unsigned int*)bitmap with:(SPStroke)stroke;
- (IBAction)undoOneStroke:(id)sender;

@end
