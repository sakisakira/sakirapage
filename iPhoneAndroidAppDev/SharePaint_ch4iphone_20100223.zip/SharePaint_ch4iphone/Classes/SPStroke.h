/*
 *  SPStroke.h
 *  SharePaint
 *
 *  Created by Akira Suzuki on 10/02/23.
 *  Copyright 2010 Akira Suzuki. All rights reserved.
 *
 */

#import <string>
#import <vector>
#import "PenProperties.h"

class SPStroke {
  public:
  long long client_time, server_time;
  std::string user_name;
  PenProperties pen_properties;
  int layer;
  std::vector<int> x_array, y_array;
  
  SPStroke(void);
  SPStroke(std::string str);
  void setup_variables(void);
  std::string toString(void);
};
