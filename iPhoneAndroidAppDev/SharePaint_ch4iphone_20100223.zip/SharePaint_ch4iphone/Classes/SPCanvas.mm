//
//  SPCanvas.mm
//  SharePaint
//
//  Created by Akira Suzuki on 10/02/23.
//  Copyright 2010 Akira Suzuki. All rights reserved.
//

#import "SPCanvas.h"
#import "algorithm"


@implementation SPCanvas


- (id)initWithCoder:(NSCoder *)decoder {
  if (self = [super initWithCoder:decoder]) {
    self->bitmap_data = NULL;
    [self setup];
  }
  return self;
}

- (void)setup {
  self->on_stroke = false;
  self->pen_properties = PenProperties();
  self->bitmap_data = NULL;
  self->width = 320;
  self->height = 480;
  [self clear_canvas];
}

- (void)clear_canvas {
  if (self->bitmap_data)
    delete[] bitmap_data;
  
  int length = self->width * self->height;
  self->bitmap_data = new unsigned int[length];
  for (int i = 0; i < length; i ++)
    self->bitmap_data[i] = 0xffffffff;

  [self setNeedsDisplay];
}


- (void)drawRect:(CGRect)rect {
  CGDataProviderRef providerref =
    CGDataProviderCreateWithData(NULL, self->bitmap_data + ((int)(rect.origin.y) * self->width + (int)(rect.origin.x)), rect.size.width * rect.size.height * 4, NULL);
  CGColorSpaceRef colorspace = CGColorSpaceCreateDeviceRGB();
  CGImageRef imgref =
  CGImageCreate(rect.size.width, rect.size.height, 8, 32, self->width * 4, colorspace, kCGImageAlphaPremultipliedFirst, providerref, NULL, NO, kCGRenderingIntentDefault);
  CGColorSpaceRelease(colorspace);
  CGDataProviderRelease(providerref);
  UIImage *img = [[UIImage alloc] initWithCGImage:imgref];
  [img drawInRect:rect];
  [img release];
  CGImageRelease(imgref);
}


- (void)dealloc {
  if (self->bitmap_data)
    delete[] self->bitmap_data;
  [super dealloc];
}

- (void)touchPressedAtX:(int)x y:(int)y {
  self->last_x = x;
  self->last_y = y;
  self->on_stroke = true;
  self->x_array.clear();
  self->y_array.clear();
  self->x_array.push_back(x);
  self->y_array.push_back(y);
}

- (void)touchDraggedAtX:(int)x y:(int)y {
  [self drawLineFromX:self->last_x y:self->last_y toX:x y:y];
  
  int pen_width_half = self->pen_properties.width / 2 + 1;
  int min_x = std::min(x, self->last_x) - pen_width_half;
  int max_x = std::max(x, self->last_x) + pen_width_half;
  int min_y = std::min(y, self->last_y) - pen_width_half;
  int max_y = std::max(y, self->last_y) + pen_width_half;
  [self setNeedsDisplayInRect:CGRectMake(min_x, min_y, max_x - min_x + 1, max_y - min_y + 1)];
  self->last_x = x;
  self->last_y = y;
  self->x_array.push_back(x);
  self->y_array.push_back(y);
}

- (void)touchReleasedAtX:(int)x y:(int)y {
  SPStroke stroke;
  stroke.user_name = "testuser";
  stroke.client_time = (long long)([[NSDate date] timeIntervalSince1970] * 1000);
  stroke.pen_properties = self->pen_properties;
  stroke.x_array = self->x_array;
  stroke.y_array = self->y_array;
  strokes_history[stroke.client_time] = stroke;
  self->on_stroke = false;
}

- (void)drawLineFromX:(int)x0 y:(int)y0 toX:(int)x1 y:(int)y1 {
  CGColorSpaceRef colorspace = CGColorSpaceCreateDeviceRGB();
  CGContextRef context =
  CGBitmapContextCreate(self->bitmap_data, self->width, self->height, 8, self->width * 4, colorspace, kCGImageAlphaPremultipliedFirst);
  CGAffineTransform ctm = CGAffineTransformMakeScale(1, -1);
  ctm = CGAffineTransformTranslate(ctm, 0, - self->height);
  CGContextConcatCTM(context, ctm);
  
  CGContextSetLineCap(context, kCGLineCapRound);
  int pen_color = self->pen_properties.color;
  CGFloat components[4];
  components[0] = (pen_color & 0x00ff0000) / (255.0 * 0x10000);
  components[1] = (pen_color & 0x0000ff00) / (255.0 * 0x100);
  components[2] = (pen_color & 0x000000ff) / 255.0;
  components[3] = (pen_color & 0xff000000) / (255.0 * 0x1000000);
  CGColorRef color = CGColorCreate(colorspace, components);
  CGContextSetStrokeColorWithColor(context, color);
  CGContextSetLineWidth(context, self->pen_properties.width);
  
  CGContextMoveToPoint(context, x0, y0);
  CGContextAddLineToPoint(context, x1, y1);
  CGContextDrawPath(context, kCGPathStroke);
  
  CGColorSpaceRelease(colorspace);
  CGColorRelease(color);
  CGContextRelease(context);
}

- (void)drawStroke:(unsigned int*)bitmap with:(SPStroke)stroke {
  CGColorSpaceRef colorspace = CGColorSpaceCreateDeviceRGB();
  CGContextRef context =
  CGBitmapContextCreate(bitmap, self->width, self->height, 8, self->width * 4, colorspace, kCGImageAlphaPremultipliedFirst);
  CGAffineTransform ctm = CGAffineTransformMakeScale(1, -1);
  ctm = CGAffineTransformTranslate(ctm, 0, - self->height);
  CGContextConcatCTM(context, ctm);
  CGContextSetLineCap(context, kCGLineCapRound);
  CGContextSetLineJoin(context, kCGLineJoinRound);
  
  int pen_color = stroke.pen_properties.color;
  CGFloat components[4];
  components[0] = (pen_color & 0x00ff0000) / (255.0 * 0x10000);
  components[1] = (pen_color & 0x0000ff00) / (255.0 * 0x100);
  components[2] = (pen_color & 0x000000ff) / 255.0;
  components[3] = (pen_color & 0xff000000) / (255.0 * 0x1000000);
  CGColorRef color = CGColorCreate(colorspace, components);
  CGContextSetStrokeColorWithColor(context, color);
  CGContextSetLineWidth(context, stroke.pen_properties.width);
  
  CGContextMoveToPoint(context, stroke.x_array[0], stroke.y_array[0]);
  for (int i = 1; i < stroke.x_array.size(); i ++)
    CGContextAddLineToPoint(context, stroke.x_array[i], stroke.y_array[i]);
  CGContextDrawPath(context, kCGPathStroke);
  
  CGColorSpaceRelease(colorspace);
  CGColorRelease(color);
  CGContextRelease(context);
}

- (IBAction)undoOneStroke:(id)sender {
  if (self->strokes_history.empty()) return;
  
  for (int i = 0; i < self->width * self->height; i ++)
    self->bitmap_data[i] = 0xffffffff;
  self->strokes_history.erase(-- self->strokes_history.end());
  
  std::map<long long, SPStroke>::iterator it =
  self->strokes_history.begin();
  while (it != self->strokes_history.end())
    [self drawStroke:self->bitmap_data with:(*(it ++)).second];
  [self setNeedsDisplay];
}


@end
