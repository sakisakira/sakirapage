//
//  SPCanvasDisplay.mm
//  SharePaint
//
//  Created by Akira Suzuki on 10/02/25.
//  Copyright 2010 Akira Suzuki. All rights reserved.
//

#import "SPCanvasDisplay.h"
#import "SPCanvas.h"

@implementation SPCanvasDisplay


- (id)initWithFrame:(CGRect)frame {
  if (self = [super initWithFrame:frame]) {
      // Initialization code
  }
  return self;
}

- (void)drawRect:(CGRect)rect {
  CGDataProviderRef providerref =
  CGDataProviderCreateWithData(NULL, 
                               canvas->display_bitmap + 
                               ((int)(rect.origin.y) * canvas->width  + (int)(rect.origin.x)), 
                               rect.size.width * rect.size.height * 4, NULL);
  CGColorSpaceRef colorspace = CGColorSpaceCreateDeviceRGB();
  CGImageRef imgref = 
  CGImageCreate(rect.size.width, rect.size.height, 8, 32,
                canvas->width  * 4, 
                colorspace,
                kCGImageAlphaPremultipliedFirst,
                providerref, NULL, NO, kCGRenderingIntentDefault);
  CGColorSpaceRelease(colorspace);
  CGDataProviderRelease(providerref);
  UIImage *img = [[UIImage alloc] initWithCGImage:imgref];
  
  [img drawInRect:rect];
  
  [img release];
  CGImageRelease(imgref);  
}


- (void)dealloc {
  [super dealloc];
}


@end

