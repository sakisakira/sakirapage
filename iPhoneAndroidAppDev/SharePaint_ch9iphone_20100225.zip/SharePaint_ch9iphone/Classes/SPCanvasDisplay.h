//
//  SPCanvasDisplay.h
//  SharePaint
//
//  Created by Akira Suzuki on 10/02/25.
//  Copyright 2010 Akira Suzuki. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SPCanvas;
@interface SPCanvasDisplay : UIView {
@public
  SPCanvas* canvas;
}

@end
