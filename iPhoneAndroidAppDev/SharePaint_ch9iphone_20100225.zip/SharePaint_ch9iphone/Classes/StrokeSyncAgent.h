/*
 *  StrokeSyncAgent.h
 *  SharePaint
 *
 *  Created by Akira Suzuki on 10/02/24.
 *  Copyright 2010 Akira Suzuki. All rights reserved.
 *
 */

#import <UIKit/UIKit.h>
#import <string>
#import <vector>
#import <map>
#import "SPStroke.h"

@class SPCanvas;
@class StrokeSyncDelegate;

class StrokeSyncAgent {
public:
  NSString* ServerURL;
  StrokeSyncDelegate* delegate;
  NSTimeInterval timeout;
  
  NSURLConnection *connection;
  bool requesting;
  NSTimeInterval last_request_time;
  
  typedef enum {None = 0, Strokes, Refresh} response;
  std::vector<std::string> queued_commands;
  std::vector<SPStroke> returned_strokes;
  bool canvas_should_be_refreshed;
  std::vector<std::string> canvas_list;
  
  SPCanvas* canvas;
  
  StrokeSyncAgent(void);
  ~StrokeSyncAgent(void);
  
  StrokeSyncAgent::response get_response(void);
  void queue_command(std::string&);
  void append_stroke(SPStroke&);
  void delete_stroke(SPStroke&);
  void get_strokes(void);
	void get_strokes_sync(void);
  void search_canvas_list(std::string nickname);
  
  void send_command(std::string&, bool sychronous = false);
	void send_queued_command(void);
	void dequeue_command(void);
  
  void clear_connection(void);
  void connectionDidFinishLoading(std::string);
  void connectionDidFailWithError(void);
};

@interface StrokeSyncDelegate : NSObject {
@public
  StrokeSyncAgent *agent;
  std::string response;
}

- (void)connection:(NSURLConnection *)conn didReceiveData:(NSData *)data;
- (void)connectionDidFinishLoading:(NSURLConnection *)conn;
- (void)connection:(NSURLConnection *)conn didFailWithError:(NSError *)error;

@end
