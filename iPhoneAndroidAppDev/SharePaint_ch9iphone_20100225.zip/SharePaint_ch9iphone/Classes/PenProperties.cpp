/*
 *  PenProperties.cpp
 *  SharePaint
 *
 *  Created by Akira Suzuki on 10/02/23.
 *  Copyright 2010 Akira Suzuki. All rights reserved.
 *
 */

#import <sstream>
#import "PenProperties.h"

PenProperties::PenProperties(int c, int w, int d) {
  this->color = c;
  this->width = w;
  this->density = d;
}

PenProperties::PenProperties(void) {
  this->color = 0xff000000;
  this->width = 3;
  this->density = 128;
}

PenProperties::PenProperties(std::string str) {
  this->color = 0xff000000;
  this->width = 3;
  this->density = 128;
  
  int ic, ie;
  std::string keyval, key, val;
  while (!str.empty()) {
    ic = str.find(",");
    if (ic >= 0) {
      keyval = str.substr(0, ic);
      str.erase(0, ic + 1);
    } else {
      keyval = str;
      str = "";
    }
    ie = keyval.find("=");
    if (ie > 0) {
      key = keyval.substr(0, ie);
      val = keyval.substr(ie + 1);
      if (key == "color") {
        std::istringstream istr(val);
        unsigned int col;
        istr >> std::hex >> col;
        this->color = col;
      } else if (key == "width") {
        std::istringstream istr(val);
        istr >> this->width;
      } else if (key == "density") {
        std::istringstream istr(val);
        istr >> this->density;
      }
    }
  }
}

std::string PenProperties::toString(void) {
	std::ostringstream strs;
	
	strs << "color=" << std::hex << color 
	<< std::dec
	<< ",width=" << width
	<< ",density=" << density;
	
	return strs.str();
}
