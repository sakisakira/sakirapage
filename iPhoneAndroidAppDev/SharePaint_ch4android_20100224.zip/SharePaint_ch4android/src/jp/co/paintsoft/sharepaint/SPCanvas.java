package jp.co.paintsoft.sharepaint;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class SPCanvas extends View {
  int width, height;
  int last_x, last_y;
  boolean on_stroke;
  PenProperties pen_properties;
  Bitmap image_buffer;
  TreeMap<Long, SPStroke> strokes_history;
  Vector<Integer> x_array, y_array;

  public SPCanvas(Context context, AttributeSet attrs) {
    super(context, attrs);
    setup();
  }
  
  void setup() {
    this.on_stroke = false;
    this.pen_properties = new PenProperties();
    this.image_buffer = null;
    this.width = 320;
    this.height = 480;
    this.strokes_history = new TreeMap<Long, SPStroke>();
    this.x_array = this.y_array = null;
    clear_canvas();
  }
  
  void clear_canvas() {
    if (this.image_buffer != null)
      this.image_buffer.recycle();
    this.image_buffer = Bitmap.createBitmap(this.width, this.height, 
        Bitmap.Config.ARGB_8888);
    this.image_buffer.eraseColor(0xffffffff);
    invalidate();
  }
  
  @Override
  protected void onDraw(Canvas canvas) {
    super.onDraw(canvas);
    if (this.image_buffer != null) {
      canvas.drawBitmap(this.image_buffer, 0, 0, null);
    }
  }
  
  @Override
  public boolean onTouchEvent(MotionEvent event) {
    if (this.image_buffer == null)
      return false;
    int x = (int)event.getX();
    int y = (int)event.getY();
    
    switch (event.getAction()) {
    case MotionEvent.ACTION_DOWN:
      touchPressed(x, y);
      break;
    case MotionEvent.ACTION_MOVE:
      touchDragged(x, y);
      break;
    case MotionEvent.ACTION_UP:
      touchReleased(x, y);
      break;
    }
    return true;
  }
  
  void touchPressed(int x, int y) {
    this.last_x = x;
    this.last_y = y;
    this.on_stroke = true;
    this.x_array = new Vector<Integer>();
    this.y_array = new Vector<Integer>();
    this.x_array.add(x);
    this.y_array.add(y);
  }
  
  void touchDragged(int x, int y) {
    drawLine(this.last_x, this.last_y, x, y);
    int pen_width_half = this.pen_properties.width / 2 + 1;
    int min_x = Math.min(x, this.last_x) - pen_width_half;
    int max_x = Math.max(x, this.last_x) + pen_width_half;
    int min_y = Math.min(y, this.last_y) - pen_width_half;
    int max_y = Math.max(y, this.last_y) + pen_width_half;
    invalidate(new Rect(min_x, min_y, max_x, max_y));
    this.last_x = x;
    this.last_y = y;
    this.x_array.add(x);
    this.y_array.add(y);
  }
  
  void touchReleased(int x, int y) {
    SPStroke stroke = new SPStroke();
    stroke.user_name = "testuser";
    stroke.client_time = System.currentTimeMillis();
    stroke.pen_properties = new PenProperties(this.pen_properties);
    stroke.x_array = this.x_array;
    stroke.y_array = this.y_array;
    strokes_history.put(stroke.client_time, stroke);
    this.x_array = this.y_array = null;
    this.on_stroke = false;
  }
  
  void drawLine(int x0, int y0, int x1, int y1) {
    Canvas canvas = new Canvas(this.image_buffer);
    Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    paint.setStrokeCap(Paint.Cap.ROUND);
    paint.setStrokeWidth(this.pen_properties.width);
    paint.setColor(this.pen_properties.color);
    canvas.drawLine(x0, y0, x1, y1, paint);
  }
  
  public void drawStroke(Bitmap bitmap, SPStroke stroke) {
    if (stroke.x_array.size() == 0) return;
    Canvas canvas = new Canvas(bitmap);
    Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    paint.setStyle(Paint.Style.STROKE);
    paint.setStrokeCap(Paint.Cap.ROUND);
    paint.setStrokeJoin(Paint.Join.ROUND);
    paint.setStrokeWidth(stroke.pen_properties.width);
    paint.setColor(stroke.pen_properties.color);
    Path path = new Path();
    path.moveTo(stroke.x_array.get(0), stroke.y_array.get(0));
    for (int i = 1; i < stroke.x_array.size(); i ++)
      path.lineTo(stroke.x_array.get(i),
          stroke.y_array.get(i));
    canvas.drawPath(path, paint);
  }
  
  public void undoOneStroke() {
    if (this.strokes_history.isEmpty()) return;
    image_buffer.eraseColor(0xffffffff);
    Set<Long> hist_times = this.strokes_history.keySet();
    Long last_time = (new TreeSet<Long>(hist_times)).last();
    hist_times.remove(last_time);
    this.strokes_history.remove(last_time);
    Iterator<Long> it = hist_times.iterator();
    while (it.hasNext())
      drawStroke(image_buffer,
          strokes_history.get(it.next()));
    invalidate();
  }
}
