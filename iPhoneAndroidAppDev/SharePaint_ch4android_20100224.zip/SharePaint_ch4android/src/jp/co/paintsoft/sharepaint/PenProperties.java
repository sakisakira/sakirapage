package jp.co.paintsoft.sharepaint;

public class PenProperties {
  int color, width, density;
  
  PenProperties(int c, int w, int d) {
    this.color = c;
    this.width = w;
    this.density = d;
  }
  
  PenProperties() {
    this.color = 0xff000000;
    this.width = 3;
    this.density = 128;
  }
  
  PenProperties(PenProperties penprop) {
    this.color = penprop.color;
    this.width = penprop.width;
    this.density = penprop.density;
  }

  PenProperties(String str) {
    this.color = 0xff000000;
    this.width = 3;
    this.density = 128;
    String[] keyvals = str.split(",");
    for (int i = 0; i < keyvals.length; i++) {
      String[] keyval = keyvals[i].split("=");
      if (keyval[0].equals("color"))
        this.color = (int)Long.parseLong(keyval[1], 16);
      else if (keyval[0].equals("width"))
        this.width = Integer.parseInt(keyval[1]);
      else if (keyval[0].equals("density"))
        this.density = Integer.parseInt(keyval[1]);
    }
  }
    
  @Override
  public String toString() {
    StringBuilder strb = new StringBuilder();
      
    strb.append("color=");
    strb.append(Integer.toHexString(color));
    strb.append(",width=" + this.width);
    strb.append(",density=" + this.density);
    
    return strb.toString();
  }

}
