package jp.co.paintsoft.sharepaint;

import java.util.Iterator;
import java.util.Vector;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.TextView.OnEditorActionListener;

public class NicknameSearch extends Activity 
  implements TextWatcher, OnEditorActionListener, OnItemClickListener {
  static String user_nickname, search_nickname;
  EditText nickname_field, search_field;
  ListView search_result_list;
  
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.nickname_search);
    
    this.nickname_field = (EditText)findViewById(R.id.nickname_field);
    this.nickname_field.setText(NicknameSearch.user_nickname);
    this.nickname_field.addTextChangedListener(this);
    this.nickname_field.setOnEditorActionListener(this);

    this.search_field = (EditText)findViewById(R.id.search_field);
    this.search_field.setText(NicknameSearch.search_nickname);
    this.search_field.setOnEditorActionListener(this);
    
    this.search_result_list = (ListView)findViewById(R.id.search_result_list);
    this.search_result_list.setOnItemClickListener(this);

    Button new_canvas_btn = (Button)findViewById(R.id.new_canvas_btn);
    new_canvas_btn.setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        SharePaint.canvas.setCanvasID("");
        setResult(RESULT_OK);
        finish();
      }});

    Button done_btn = (Button)findViewById(R.id.nickname_done_btn);
    done_btn.setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        setResult(RESULT_OK);
        finish();
      }});
  }
  
  public void afterTextChanged(Editable s) {
    NicknameSearch.user_nickname = s.toString();
  }
  public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
  public void onTextChanged(CharSequence s, int start, int before, int count) {}
  
  public boolean onEditorAction(TextView v, int id, KeyEvent e) {
    if (e != null && e.getAction() == KeyEvent.ACTION_UP){
      hideInputMethod();
      if (v == this.nickname_field) {
        NicknameSearch.user_nickname = v.getText().toString();
      } else if (v == this.search_field) {
        NicknameSearch.search_nickname = v.getText().toString();
        searchRequest(v.getText().toString());
      }
    } 
    return true;
  }
  
  void hideInputMethod() {
    InputMethodManager m = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
    m.toggleSoftInput(InputMethodManager.SHOW_IMPLICIT, 
        InputMethodManager.HIDE_NOT_ALWAYS);
  }

  void searchRequest(String nickname) {
    StrokeSyncAgent syncagent;
    syncagent = new StrokeSyncAgent(SharePaint.canvas);
    syncagent.search_canvas_list(nickname);
    Vector<String> canvas_list = syncagent.canvas_list;
    
    ArrayAdapter<String> adapter
      = new ArrayAdapter<String>(this, 
          R.layout.search_result_textview,
          R.id.search_result_textview);
    Iterator<String> it = canvas_list.iterator();
    while (it.hasNext())
      adapter.add(it.next());
    this.search_result_list.setAdapter(adapter);
  }

  public void onItemClick(AdapterView<?> parent, View view, int a, long b) {
    TextView textview = (TextView)view;
    String canvas_name = textview.getText().toString();
    SharePaint.canvas.setCanvasID(canvas_name);
    setResult(RESULT_OK);
    finish();
  }

}
