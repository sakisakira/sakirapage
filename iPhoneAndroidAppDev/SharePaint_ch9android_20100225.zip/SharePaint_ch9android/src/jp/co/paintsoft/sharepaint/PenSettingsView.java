package jp.co.paintsoft.sharepaint;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.CompoundButton.OnCheckedChangeListener;

public class PenSettingsView extends Activity 
implements OnCheckedChangeListener {
  SeekBar pen_width_slider = null;
  SeekBar pen_density_slider = null;
  RadioButton[] pen_color_btns = new RadioButton[3];
  RadioButton[] layer_index_btns = new RadioButton[3];
  Button hsbcolorbox_btn = null;
  int pen_color;

  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.pen_properties);
    pen_width_slider = (SeekBar)findViewById(R.id.pen_width);
    pen_density_slider = (SeekBar)findViewById(R.id.pen_density);
    pen_color_btns[0] = (RadioButton)findViewById(R.id.pencolor_black);
    pen_color_btns[1] = (RadioButton)findViewById(R.id.pencolor_white);
    pen_color_btns[2] = (RadioButton)findViewById(R.id.pencolor_other);
    pen_color_btns[0].setOnCheckedChangeListener(this);
    pen_color_btns[1].setOnCheckedChangeListener(this);
    pen_color_btns[2].setOnCheckedChangeListener(this);
    hsbcolorbox_btn = (Button)findViewById(R.id.penhsbcolbox);
    hsbcolorbox_btn.setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        showHSBColorPicker();
      }});
    
    layer_index_btns[0] = (RadioButton)findViewById(R.id.layer_0);
    layer_index_btns[1] = (RadioButton)findViewById(R.id.layer_1);
    layer_index_btns[2] = (RadioButton)findViewById(R.id.layer_2);

    int pen_width = getIntent().getIntExtra(SharePaint.PenWidthName, -1);
    if (pen_width >= 0)
      pen_width_slider.setProgress(pen_width);
    int pen_density = getIntent().getIntExtra(SharePaint.PenDensityName, -1);
    if (pen_density >= 0)
      pen_density_slider.setProgress(pen_density);
    int pen_color = getIntent().getIntExtra(SharePaint.PenColorName, 0);
    if (pen_color != 0)
      setColorButton(pen_color);
    int layer_index = getIntent().getIntExtra(SharePaint.LayerIndexName, -1);
    if (layer_index >= 0)
      layer_index_btns[layer_index].setChecked(true);
    Button cancel_btn = (Button)findViewById(R.id.pen_prop_cancel);
    Button ok_btn = (Button)findViewById(R.id.pen_prop_ok);
    cancel_btn.setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        setResult(RESULT_CANCELED);
        finish();
      }});
    ok_btn.setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        okButtonPressed();
      }});
  }
  
  void setColorButton(int col) {
    this.pen_color = col;
    if (col == 0xff000000)  // ��
      pen_color_btns[0].setChecked(true);
    else if (col == 0xffffffff)  // ��
      pen_color_btns[1].setChecked(true);
    else  // ����ȊO
      pen_color_btns[2].setChecked(true);
    setColorBox();
  }

  
  void okButtonPressed() {
    Intent intent = new Intent();
    intent.putExtra(SharePaint.PenWidthName, 
        pen_width_slider.getProgress());
    intent.putExtra(SharePaint.PenDensityName, 
        pen_density_slider.getProgress());
    intent.putExtra(SharePaint.PenColorName, 
        this.pen_color);
    int layer_index = -1;
    for (int i = 0; i < 3; i ++)
      if (layer_index_btns[i].isChecked())
        layer_index = i;
   intent.putExtra(SharePaint.LayerIndexName,
       layer_index);
    setResult(RESULT_OK, intent);
    finish();
  }
  
  void showHSBColorPicker() {
    Intent intent = new Intent(PenSettingsView.this,
        HSBColorPicker.class);
    intent.putExtra(SharePaint.PenColorName, 
        PenSettingsView.this.pen_color);
    startActivityForResult(intent,
        SharePaint.ShowHSBColorPickerId);
  }

  @Override
  protected void onActivityResult(int reqid, int result, Intent intent) {
    if (result == RESULT_OK) {
      int pen_color = intent.getIntExtra(SharePaint.PenColorName, 0);
      if (pen_color != 0) 
        this.pen_color = pen_color;
      setColorBox();
      this.pen_color_btns[2].setSelected(true);
    }
  }

  void setColorBox() {
    this.hsbcolorbox_btn.setBackgroundColor(this.pen_color);
  }

  public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
    if (this.pen_color_btns[0].isChecked()) {
      this.pen_color = 0xff000000;
      setColorBox();
    } else if (this.pen_color_btns[1].isChecked()) {
      this.pen_color = 0xffffffff;
      setColorBox();
    } else if (this.pen_color_btns[2].isChecked()) {
      showHSBColorPicker();
    }
  }

}
