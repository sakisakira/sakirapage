package jp.co.paintsoft.sharepaint;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public class HueLine extends View {

  public HueLine(Context context, AttributeSet attrs) {
    super(context, attrs);
  }
  
  @Override
  protected void onDraw(Canvas canvas) {
    int width = getWidth();
    int height = getHeight();
    
    float[] hsv = new float[3];
    hsv[1] = 1.0f;
    hsv[2] = 1.0f;
    Paint paint = new Paint();
    for (int x = 0; x < width; x ++) {
      hsv[0] = 360f * x / width;
      paint.setColor(Color.HSVToColor(hsv));
      canvas.drawLine(x, 0, x, height - 1, paint);
    } 
  }

}
