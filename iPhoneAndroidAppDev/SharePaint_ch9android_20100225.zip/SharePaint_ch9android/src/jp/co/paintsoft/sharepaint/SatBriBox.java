package jp.co.paintsoft.sharepaint;

import java.util.EventListener;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;

public class SatBriBox extends View 
    implements OnSeekBarChangeListener, EventListener {
  int hue;  // [0�`360)
  View pencolbox;

  public SatBriBox(Context context, AttributeSet attrs) {
    super(context, attrs);
  }
  
  @Override
  protected void onDraw(Canvas canvas) {
    final float count = 50f;
    float[] hsv = new float[3];
    hsv[0] = (float)this.hue;
    Paint paint = new Paint();
    float width = (float)getWidth();
    float height = (float)getHeight();
    float stepx = width / count;
    float stepy = height / count;
    for (float y = 0; y < height; y += stepy)
      for (float x = 0; x < width; x += stepx) {
        hsv[1] = x / width;
        hsv[2] = y / height;
        paint.setColor(Color.HSVToColor(hsv));
        canvas.drawRect(x, y, x + stepx, y + stepy, paint);
      }
  }

  public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {}
  public void onStartTrackingTouch(SeekBar seekBar) {}
  
  public void onStopTrackingTouch(SeekBar seekBar) {
    this.hue = seekBar.getProgress();
    invalidate();
  }
  
  void touchAt(float x, float y) {
    float width = getWidth();
    float height = getHeight();
    float[] hsv = new float[3];
    hsv[0] = (float)this.hue;
    hsv[1] = x / width;
    hsv[2] = y / height;
    int col = Color.HSVToColor(hsv);
    this.pencolbox.setBackgroundColor(col);
    HSBColorPicker.pen_color = col;
  }
  
  @Override
  public boolean onTouchEvent(MotionEvent event) {
    touchAt(event.getX(), event.getY());
    return true;
  }
}
