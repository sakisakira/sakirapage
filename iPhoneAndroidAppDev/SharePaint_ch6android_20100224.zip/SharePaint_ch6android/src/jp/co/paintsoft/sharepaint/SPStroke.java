package jp.co.paintsoft.sharepaint;

import java.util.Vector;

public class SPStroke {
  long client_time, server_time;
  String user_name;
  PenProperties pen_properties;
  int layer;
  Vector<Integer> x_array, y_array;
  
  @Override
  public String toString() {
    StringBuilder strb = new StringBuilder();
    
    strb.append(" clinet_time:" + client_time);
    strb.append(" server_time:" + server_time);
    strb.append(" user_name:" + user_name);
    strb.append(" pen_properties:" + pen_properties);
    strb.append(" layer:" + layer);
    
    strb.append(" points:");
    for (int i = 0; i < x_array.size(); i ++) {
      strb.append(" " + x_array.get(i));
      strb.append("-" + y_array.get(i));
    }
    return strb.toString();
  }
  
  void setup_variables() {
    client_time = server_time = layer = 0;
    user_name = null;
    pen_properties = null;
  }
  
  public SPStroke() {
    setup_variables();
    x_array = y_array = null;
  }
  
  public SPStroke(String str) {
    setup_variables();
    x_array = new Vector<Integer>();
    y_array = new Vector<Integer>();
    String[] tag_point = str.split(" points:");
    String[] keyvals = tag_point[0].split("\\s");
    for (int i = 0; i < keyvals.length; i ++) {
      String[] keyval = keyvals[i].split(":");
      if (keyval[0].equals("client_time"))
        client_time = Long.parseLong(keyval[1]);
      else if (keyval[0].equals("server_time"))
        this.server_time = Long.parseLong(keyval[1]);
      else if (keyval[0].equals("pen_properties"))
        this.pen_properties = new PenProperties(keyval[1]);
      else if (keyval[0].equals("layer"))
        this.layer = Integer.parseInt(keyval[1]);
      else if (keyval[0].equals("user_name"))
        this.user_name = keyval[1];
    }
    if (tag_point.length < 2) return;
    
    String[] xys = tag_point[1].split("\\s");
    for (int i = 0; i < xys.length; i ++) {
      String[] xy = xys[i].split("-");
      if (xy.length == 2) {
        x_array.add(Integer.parseInt(xy[0]));
        y_array.add(Integer.parseInt(xy[1]));
      }
    }
  }
  
}
