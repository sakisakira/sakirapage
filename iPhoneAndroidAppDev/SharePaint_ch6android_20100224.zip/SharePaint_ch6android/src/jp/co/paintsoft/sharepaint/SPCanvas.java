package jp.co.paintsoft.sharepaint;

import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;
import java.util.TimeZone;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class SPCanvas extends View {
  static final long InitServerTime = (long)10000 * 365 * 24 * 60 * 60 * 1000;
  int width, height;
  int last_x, last_y;
  boolean on_stroke;
  PenProperties pen_properties;
  Bitmap image_buffer;
  TreeMap<Times, SPStroke> strokes_history;
  Vector<Integer> x_array, y_array;
  String user_nickname, canvas_id, user_id;
  StrokeSyncAgent sync_agent;

  class Times implements Comparable<Times> {
    long server, client;

    public int compareTo(Times t2) {
      Times t1 = this;
      if (t1.server < t2.server)
        return -1;
      else if (t1.server > t2.server)
        return 1;
      else {
        if (t1.client < t2.client)
          return -1;
        else if (t1.client > t2.client)
          return 1;
      }
      return 0;
    }
    
    public boolean equals(Times t) {
      return (this.server == t.server) && (this.client == t.client);
    }
    
    @Override
    public boolean equals(Object o) {
      if (o instanceof Times) {
        Times t = (Times)o;
        return (this.server == t.server) && (this.client == t.client);
      }
      return (this == o);
    }
  }

  public SPCanvas(Context context, AttributeSet attrs) {
    super(context, attrs);
    setup();
  }
  
  void setup() {
    this.on_stroke = false;
    this.pen_properties = new PenProperties();
    this.image_buffer = null;
    this.width = 320;
    this.height = 480;
    this.strokes_history = new TreeMap<Times, SPStroke>();
    this.user_nickname = "android";
    this.canvas_id = "";
    this.user_id = "";
    this.sync_agent = new StrokeSyncAgent(this);
    this.x_array = this.y_array = null;
    clear_canvas();
  }
  
  void clear_canvas() {
    if (this.image_buffer != null)
      this.image_buffer.recycle();
    this.image_buffer = Bitmap.createBitmap(this.width, this.height, 
        Bitmap.Config.ARGB_8888);
    this.image_buffer.eraseColor(0xffffffff);
    invalidate();
    
    SPStroke stroke = new SPStroke();
    stroke.user_name = userID();
    stroke.client_time = System.currentTimeMillis();
    stroke.pen_properties = new PenProperties();
    stroke.x_array = stroke.y_array = new Vector<Integer>();
    this.sync_agent.append_stroke(stroke);
    this.sync_agent.get_strokes();
  }
  
  @Override
  protected void onDraw(Canvas canvas) {
    super.onDraw(canvas);
    if (this.image_buffer != null) {
      canvas.drawBitmap(this.image_buffer, 0, 0, null);
    }
  }
  
  @Override
  public boolean onTouchEvent(MotionEvent event) {
    if (this.image_buffer == null)
      return false;
    int x = (int)event.getX();
    int y = (int)event.getY();
    
    switch (event.getAction()) {
    case MotionEvent.ACTION_DOWN:
      touchPressed(x, y);
      break;
    case MotionEvent.ACTION_MOVE:
      touchDragged(x, y);
      break;
    case MotionEvent.ACTION_UP:
      touchReleased(x, y);
      break;
    }
    return true;
  }
  
  void touchPressed(int x, int y) {
    this.last_x = x;
    this.last_y = y;
    this.on_stroke = true;
    this.x_array = new Vector<Integer>();
    this.y_array = new Vector<Integer>();
    this.x_array.add(x);
    this.y_array.add(y);
  }
  
  void touchDragged(int x, int y) {
    drawLine(this.last_x, this.last_y, x, y);
    int pen_width_half = this.pen_properties.width / 2 + 1;
    int min_x = Math.min(x, this.last_x) - pen_width_half;
    int max_x = Math.max(x, this.last_x) + pen_width_half;
    int min_y = Math.min(y, this.last_y) - pen_width_half;
    int max_y = Math.max(y, this.last_y) + pen_width_half;
    invalidate(new Rect(min_x, min_y, max_x, max_y));
    this.last_x = x;
    this.last_y = y;
    this.x_array.add(x);
    this.y_array.add(y);
  }
  
  void touchReleased(int x, int y) {
    SPStroke stroke = new SPStroke();
    stroke.user_name = this.userID();
    stroke.client_time = System.currentTimeMillis();
    stroke.pen_properties = new PenProperties(this.pen_properties);
    stroke.x_array = this.x_array;
    stroke.y_array = this.y_array;
    Times times = new Times();
    times.server = SPCanvas.InitServerTime;
    times.client = stroke.client_time;
    strokes_history.put(times, stroke);
    this.x_array = this.y_array = null;
    
    this.on_stroke = false;
    get_response();
    this.sync_agent.append_stroke(stroke);
  }
  
  void drawLine(int x0, int y0, int x1, int y1) {
    Canvas canvas = new Canvas(this.image_buffer);
    Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    paint.setStrokeCap(Paint.Cap.ROUND);
    paint.setStrokeWidth(this.pen_properties.width);
    paint.setColor(this.pen_properties.color);
    canvas.drawLine(x0, y0, x1, y1, paint);
  }
  
  public void drawStroke(Bitmap bitmap, SPStroke stroke) {
    if (stroke.x_array.size() == 0) return;
    Canvas canvas = new Canvas(bitmap);
    Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    paint.setStyle(Paint.Style.STROKE);
    paint.setStrokeCap(Paint.Cap.ROUND);
    paint.setStrokeJoin(Paint.Join.ROUND);
    paint.setStrokeWidth(stroke.pen_properties.width);
    paint.setColor(stroke.pen_properties.color);
    Path path = new Path();
    path.moveTo(stroke.x_array.get(0), stroke.y_array.get(0));
    for (int i = 1; i < stroke.x_array.size(); i ++)
      path.lineTo(stroke.x_array.get(i),
          stroke.y_array.get(i));
    canvas.drawPath(path, paint);
  }
  
  public void undoOneStroke() {
    if (this.strokes_history.isEmpty()) return;  
    // �X�g���[�N���܂��������Ă��Ȃ���Ή������Ȃ�

    Set<Times> hist_times_set = this.strokes_history.keySet();
    // �~����TreeSet���쐬
    TreeSet<Times> hist_times = new TreeSet<Times>(new Comparator<Times>() {
      public int compare(Times t1, Times t2) {
        return -1 * t1.compareTo(t2);
      }});
    hist_times.addAll(hist_times_set);

    // �V�����X�g���[�N���猟��
    Iterator<Times> it = hist_times.iterator();
    while (it.hasNext()) {
      Times times = it.next();
      SPStroke stroke = this.strokes_history.get(times);
      if (stroke.user_name.equals(userID())) {
        // ���������̃X�g���[�N�����t��������
        this.sync_agent.delete_stroke(stroke);
        // �X�g���[�N�폜���T�[�o�֒ʒm����
        this.strokes_history.remove(times);  // ������폜����
        redrawStrokes(this.image_buffer);  // �ĕ`�悵��
        return;  // �A��
      }
    }
  }
  
  public String canvasID() {
    this.canvas_id = "testuser@19700101000000000";
    if (this.canvas_id.length() == 0) {
      SimpleDateFormat date_format;
      date_format = new SimpleDateFormat("yyyyMMddHHmmssSSS");
      date_format.setTimeZone(TimeZone.getTimeZone("GMT"));
      this.canvas_id = this.user_nickname + "@" + date_format.format(new Date());
    }
    return this.canvas_id;
  }
  
  public String userID() {
    if (this.user_id.length() == 0) {
      SimpleDateFormat date_format;
      date_format = new SimpleDateFormat("yyyyMMddHHmmssSSS");
      date_format.setTimeZone(TimeZone.getTimeZone("GMT"));
      this.user_id = this.user_nickname + "@" + date_format.format(new Date());
    }
    return this.user_id;
  }
  
  public void redrawStrokes(Bitmap bitmap) {
    bitmap.eraseColor(0xffffffff); // ���őS�̂�h��ׂ�
    
    Set<Times> hist_times = this.strokes_history.keySet();
        //  �X�g���[�N�����������S�����̏W�����擾
    Iterator<Times> it = hist_times.iterator();
    SPStroke stroke;
    while (it.hasNext()) {
      stroke = strokes_history.get(it.next());
          drawStroke(bitmap, stroke);
    }

    invalidate();
  }
  
  public void get_response() {
    boolean should_be_refresh = false;  // �L�����o�X�ĕ`��t���O
    Iterator<SPStroke> it;
      // �X�g���[�N�p�̃C�e���[�^��錾 
    
    synchronized (this.sync_agent.returned_strokes) {
    switch (this.sync_agent.get_response()) {
    case StrokeSyncAgent.Strokes: // �����X�g���[�N�������
        it = this.sync_agent.returned_strokes.iterator();
        while (it.hasNext()) {
          SPStroke stroke = it.next();
          if (stroke.user_name.equals(userID())) {
            Times otimes = new Times();
            otimes.server = SPCanvas.InitServerTime;
            otimes.client = stroke.client_time;
            this.strokes_history.remove(otimes);
          } else {
            should_be_refresh = true;
          }
          Times ntimes = new Times();
          ntimes.server = stroke.server_time;
          ntimes.client = stroke.client_time;
          this.strokes_history.put(ntimes, stroke);
        }
        // �T�[�o����߂��Ă����S�X�g���[�N�̏������I��������
        this.sync_agent.returned_strokes.clear();
        if (should_be_refresh) // �����L�����o�X�X�V�t���O�������Ă����
          redrawStrokes(this.image_buffer);
        break;
      case StrokeSyncAgent.Refresh:
        this.sync_agent.canvas_should_be_refreshed = false; // �t���O���N���A
        this.strokes_history.clear(); // �X�g���[�N����j��
        this.sync_agent.get_strokes();
      }
    }
  }


  
}
