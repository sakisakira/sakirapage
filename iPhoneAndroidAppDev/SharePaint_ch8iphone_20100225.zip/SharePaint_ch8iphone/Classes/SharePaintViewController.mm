//
//  SharePaintViewController.m
//  SharePaint
//
//  Created by Akira Suzuki on 10/02/23.
//  Copyright Akira Suzuki 2010. All rights reserved.
//

#import "SharePaintViewController.h"
#import "SPCanvas.h"

@implementation SharePaintViewController



/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
  SPCanvas* canvas = (SPCanvas*)self.view;
  if (canvas->prev_bitmap == NULL) return;
  UITouch *touch = [touches anyObject];
  if (touch) {
    CGPoint pt = [touch locationInView:canvas];
    [canvas touchPressedAtX:pt.x y:pt.y];
  }
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
  SPCanvas* canvas = (SPCanvas*)self.view;
  if (canvas->prev_bitmap == NULL) return;
  UITouch *touch = [touches anyObject];
  if (touch) {
    CGPoint pt = [touch locationInView:canvas];
    [canvas touchDraggedAtX:pt.x y:pt.y];
  }
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
  SPCanvas* canvas = (SPCanvas*)self.view;
  if (canvas->prev_bitmap == NULL) return;
  UITouch *touch = [touches anyObject];
  if (touch) {
    CGPoint pt = [touch locationInView:canvas];
    [canvas touchReleasedAtX:pt.x y:pt.y];
  }
}

- (IBAction)showPenPropDialog:(id)sender {
  SPCanvas* canvas = (SPCanvas*)self.view;
  [self setColorButton:canvas->pen_properties.color];
  self->pen_width_slider.minimumValue = 1;
  self->pen_width_slider.maximumValue = 25;
  self->pen_width_slider.value = canvas->pen_properties.width;
  self->pen_density_slider.minimumValue = 0;
  self->pen_density_slider.maximumValue = 255;
  self->pen_density_slider.value = canvas->pen_properties.density;
  self->layer_btns.selectedSegmentIndex = canvas->layer_index;
  [self presentModalViewController:penpropviewcontroller animated:YES];
}

- (void)setColorButton:(int)col {
  if (col == 0xff000000)
    pen_color_btns.selectedSegmentIndex = 0;
  else if (col == 0xffffffff)
    pen_color_btns.selectedSegmentIndex = 1;
  else
    pen_color_btns.selectedSegmentIndex = 2;

  [self setColorBoxes];
}

- (IBAction)applyPenPropDialog:(id)sender {
  SPCanvas* canvas = (SPCanvas*)self.view;
  canvas->pen_properties.width = (int)self->pen_width_slider.value;
  canvas->pen_properties.density = (int)self->pen_density_slider.value;
  [canvas setLayerIndex:self->layer_btns.selectedSegmentIndex];
  [self dismissModalViewControllerAnimated:YES];
}

- (IBAction)dismissPenPropDialog:(id)sender {
  [self dismissModalViewControllerAnimated:YES];
}

- (IBAction)showHSBColorPicker:(id)sender {
  self->hue_slider.minimumValue = 0.0;
  self->hue_slider.maximumValue = 1.0;
  
  [self setColorBoxes];
  
	SPCanvas* canvas = (SPCanvas*)self.view;
	int pc = canvas->pen_properties.color;
	float red = (pc & 0xff0000) / (0x10000 * 255.0);
	float gre = (pc & 0x00ff00) / (0x00100 * 255.0);
	float blu = (pc & 0x0000ff) / (0x00001 * 255.0);
	float hue;
	float cmax = std::max(std::max(red, gre), blu);
  float cmin = std::min(std::min(red, gre), blu);
  if (cmax > cmin) {
    if (cmax == red)
      hue = (gre - blu) / (cmax - cmin) + 0.0;
    else if (cmax == gre)
      hue = (blu - red) / (cmax - cmin) + 2.0;
    else {
      hue = (red - gre) / (cmax - cmin) + 4.0;
    }
    if (hue < 0) hue += 6.0;
    self->hue_slider.value = hue / 6.0;
  }
	
	[self->penpropviewcontroller
   presentModalViewController:hsbcolorpickercontroller
   animated:YES];
}

- (IBAction)applyHSBColorPicker:(id)sender {
  SPCanvas* canvas = (SPCanvas*)self.view;
  CGColorRef pencolor = self->penhsbcolbox.backgroundColor.CGColor;
  const CGFloat* pccomp = CGColorGetComponents(pencolor);
  int pencolint = 0xff000000 | (int)(pccomp[0] * 255) << 16 |
  (int)(pccomp[1] * 255) << 8 | (int)(pccomp[2] * 255);
  canvas->pen_properties.color = pencolint;
  
  [self setColorBoxes];
  self->pen_color_btns.selectedSegmentIndex = 2;
  
	[self->penpropviewcontroller
   dismissModalViewControllerAnimated:YES];
}

- (IBAction)dismissHSBColorPicker:(id)sender {
	[self->penpropviewcontroller
   dismissModalViewControllerAnimated:YES];
}

- (void)setColorBoxes {
  SPCanvas* canvas = (SPCanvas*)self.view;
  int pc = canvas->pen_properties.color;
  float red = (pc & 0xff0000) / (0x10000 * 255.0);
  float gre = (pc & 0x00ff00) / (0x00100 * 255.0);
  float blu = (pc & 0x0000ff) / (0x00001 * 255.0);
  UIColor* pencolor = [UIColor colorWithRed:red green:gre blue:blu alpha:1.0];
  self->pendlgcolbox.backgroundColor = pencolor;
  self->penhsbcolbox.backgroundColor = pencolor;
}

- (IBAction)penRadioButtonPressed:(id)sender {
  if (self->pen_color_btns.selectedSegmentIndex == 0) {
    ((SPCanvas*)self.view)->pen_properties.color = 0xff000000;
    [self setColorBoxes];
  } else if (self->pen_color_btns.selectedSegmentIndex == 1) {
    ((SPCanvas*)self.view)->pen_properties.color = 0xffffffff;
    [self setColorBoxes];
  } else if (self->pen_color_btns.selectedSegmentIndex == 2) {
    [self->penpropviewcontroller presentModalViewController:hsbcolorpickercontroller animated:YES];
  }
}

- (IBAction)showNicknameView:(id)sender {
	SPCanvas* canvas = (SPCanvas*)self.view;
	NSString* nickname = [NSString stringWithUTF8String:canvas->user_nickname.c_str()];
	self->nickname_field.text = nickname;
	[self presentModalViewController:nicknameviewcontroller animated:YES];
}

- (IBAction)dismissNicknameView:(id)sender {
	[self dismissModalViewControllerAnimated:YES];
}

- (IBAction)nicknameChanged:(id)sender {
	[sender resignFirstResponder];
	NSString* nickname = [self->nickname_field.text
                        stringByReplacingOccurrencesOfString:@" "
                        withString:@""];
	SPCanvas* canvas = (SPCanvas*)self.view;
	[canvas setNickname:[nickname UTF8String]];
}

- (IBAction)newCanvasPressed:(id)sender {
	SPCanvas* canvas = (SPCanvas*)self.view;
	[canvas setCanvasID:""];
	[self dismissNicknameView:nil];
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
	[searchBar resignFirstResponder];
  StrokeSyncAgent syncagent;
  syncagent.canvas = (SPCanvas*)self.view;
  NSString* nickname = [searchBar.text
                        stringByReplacingOccurrencesOfString:@" "
                        withString:@""];
  syncagent.search_canvas_list(std::string([nickname UTF8String]));
	self->canvas_list = syncagent.canvas_list;
	[search_result_table reloadData];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return canvas_list.size();
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	
	static NSString *CellIdentifier = @"SearchResult";
	
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
	}
	NSString* canvas_name;
	int index = indexPath.row;
	canvas_name = [NSString 
								 stringWithUTF8String:canvas_list[index].c_str()];
	cell.textLabel.text = canvas_name;
	
	return cell;
}

- (void)tableView:(UITableView *)tableView 
didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	SPCanvas* canvas = (SPCanvas*)self.view;
	[canvas setCanvasID:canvas_list[indexPath.row]];
	[self dismissNicknameView:nil];
}

@end
