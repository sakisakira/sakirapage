//
//  HSBColorPicker.h
//  SharePaint
//
//  Created by Akira Suzuki on 10/02/25.
//  Copyright 2010 Akira Suzuki. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface HSBColorPicker : NSObject {}
@end

@class SatBriBox;
@interface HueLine : UIView {
  IBOutlet UISlider* hue_slider;
  IBOutlet SatBriBox* satbribox;
}
@end

@interface SatBriBox : UIView {
	IBOutlet UISlider* hue_slider;
	IBOutlet UIView* pencolbox;
}
- (IBAction)hueChanged:(id)sender;
- (void)touchAt:(CGPoint)pt;
@end

