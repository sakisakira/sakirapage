//
//  SharePaintViewController.h
//  SharePaint
//
//  Created by Akira Suzuki on 10/02/23.
//  Copyright Akira Suzuki 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HSBColorPicker.h"
#import "StrokeSyncAgent.h"
#import "SPCanvas.h"


@interface SharePaintViewController : UIViewController 
  <UITableViewDelegate, UITableViewDataSource> {
  IBOutlet UIViewController* penpropviewcontroller;
  IBOutlet UISegmentedControl* pen_color_btns;
  IBOutlet UISlider* pen_width_slider;
  IBOutlet UISlider* pen_density_slider;
  IBOutlet UISegmentedControl* layer_btns;
  IBOutlet UIViewController* hsbcolorpickercontroller;
  IBOutlet UISlider* hue_slider;
  IBOutlet UIButton* pendlgcolbox;
  IBOutlet UIView* penhsbcolbox;
  IBOutlet UIViewController* nicknameviewcontroller;
  IBOutlet UITextField* nickname_field;
  IBOutlet UITableView* search_result_table;
  std::vector<std::string> canvas_list; 

}

- (IBAction)showPenPropDialog:(id)sender;
- (void)setColorButton:(int)col;
- (IBAction)applyPenPropDialog:(id)sender;
- (IBAction)dismissPenPropDialog:(id)sender;
- (IBAction)showHSBColorPicker:(id)sender;
- (IBAction)dismissHSBColorPicker:(id)sender;
- (IBAction)applyHSBColorPicker:(id)sender;
- (void)setColorBoxes;
- (IBAction)penRadioButtonPressed:(id)sender;
- (IBAction)showNicknameView:(id)sender;
- (IBAction)dismissNicknameView:(id)sender;
- (IBAction)nicknameChanged:(id)sender;
- (IBAction)newCanvasPressed:(id)sender;
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar;
- (void)tableView:(UITableView *)tableView 
didSelectRowAtIndexPath:(NSIndexPath *)indexPath;

@end

