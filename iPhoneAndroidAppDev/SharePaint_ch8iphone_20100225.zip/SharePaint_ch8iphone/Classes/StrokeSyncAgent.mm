/*
 *  StrokeSyncAgent.mm
 *  SharePaint
 *
 *  Created by Akira Suzuki on 10/02/24.
 *  Copyright 2010 Akira Suzuki. All rights reserved.
 *
 */

#import "SPCanvas.h"
#import "StrokeSyncAgent.h"

StrokeSyncAgent::StrokeSyncAgent(void) {
  this->ServerURL = @"http://sharepaintserver.appspot.com/";
  this->delegate = [[StrokeSyncDelegate alloc] init];
  this->delegate->agent = this;
  this->timeout = 10.0;
  
  this->connection = nil;
  this->requesting = false;
  this->last_request_time = 0.0;
  
  this->queued_commands.clear();
  this->returned_strokes.clear();
  this->canvas_should_be_refreshed = false;
  this->canvas_list.clear();
}

StrokeSyncAgent::~StrokeSyncAgent(void) {
  [this->delegate release];
  [this->connection release];
}

StrokeSyncAgent::response StrokeSyncAgent::get_response(void) {
  if (this->canvas_should_be_refreshed)
    return Refresh;
  else if (!this->returned_strokes.empty())
    return Strokes;
  else 
    return None;
}

void StrokeSyncAgent::send_command(std::string& cmd, bool synchronous) {
    // storkeからサーバに渡すデータをNSDataで作成
  NSData* body = [NSData dataWithBytes:cmd.data() length:cmd.size()];
  
    // そのデータをサーバへ送信
  NSMutableURLRequest* request = 
  [NSMutableURLRequest requestWithURL:[NSURL URLWithString:this->ServerURL]];
  [request setTimeoutInterval:this->timeout];
  [request setHTTPMethod:@"POST"];
  [request setHTTPBody:body];
  if (synchronous) {
      // 同期
    NSURLResponse *response;
    NSData *data = [NSURLConnection 
                    sendSynchronousRequest:request
                    returningResponse:&response
                    error:NULL];
    if (data) {
      std::string str((char *)[data bytes], [data length]);
      connectionDidFinishLoading(str);
    }
  } else {
      // 非同期
    this->connection = [[NSURLConnection alloc]
                        initWithRequest:request delegate:this->delegate
                        startImmediately:YES];
    this->requesting = true;
    this->last_request_time = [[NSDate date] timeIntervalSince1970];
  }
}

void StrokeSyncAgent::queue_command(std::string& cmd) {
	@synchronized (this->delegate) {
    this->queued_commands.push_back(cmd);
	}
	
	if (this->requesting) {
		if (this->last_request_time + this->timeout <
				[[NSDate date] timeIntervalSince1970])
			connectionDidFailWithError();
		else {
			return;
		}
	}
	
	send_queued_command();
}

void StrokeSyncAgent::send_queued_command(void) {
	@synchronized (this->delegate) {
  	if (!this->queued_commands.empty())
      send_command(queued_commands[0], false);
	}
}

void StrokeSyncAgent::dequeue_command(void) {
	@synchronized (this->delegate) {
    if (!this->queued_commands.empty())
      this->queued_commands.erase(this->queued_commands.begin());
	}
}

void StrokeSyncAgent::append_stroke(SPStroke& stroke) {
  std::string cmd = [this->canvas canvasID] + ": append: " + stroke.toString();
  queue_command(cmd);
}

void StrokeSyncAgent::delete_stroke(SPStroke& stroke) {
  stroke.x_array.clear();
  stroke.y_array.clear();
  std::string cmd = [this->canvas canvasID] + ": delete: " + stroke.toString();
  queue_command(cmd);
}

void StrokeSyncAgent::get_strokes(void) {
  std::string cmd = [this->canvas canvasID] + ": get_strokes: ";
  queue_command(cmd);
}

void StrokeSyncAgent::get_strokes_sync(void) {
  std::string cmd = [this->canvas canvasID] + ": get_strokes: ";
  send_command(cmd, true);
}


void StrokeSyncAgent::search_canvas_list(std::string nickname) {
  std::string cmd = [this->canvas canvasID] + 
  ": search_canvas_list: nickname:" + nickname;
  send_command(cmd, true);
}

void StrokeSyncAgent::clear_connection(void) {
  [this->connection release];
  this->connection = nil;
  this->requesting = false;
  this->last_request_time = 0.0;
}


void StrokeSyncAgent::connectionDidFinishLoading(std::string str) {
  unsigned int start_i, end_i;
  std::string line;
  
  clear_connection();
  
  @synchronized (this->delegate) {
    start_i = end_i = 0;
    while (start_i != std::string::npos) {
      end_i = str.find("\n", start_i);
      if (end_i != std::string::npos) {
        line = str.substr(start_i, end_i - start_i);
        start_i = end_i + 1;
      } else {
        line = str.substr(start_i);
        start_i = std::string::npos;
      }
      
      if (line.size() > 0) {
        std::string::iterator bi, ei;
        bi = line.begin();
        ei = line.end();
        while (isspace(*bi) && (bi != line.end())) bi ++;
        while (isspace(*ei) && (ei != line.begin())) ei --;
        line = std::string(bi, ei);
      }
      
      if (line.find(" append: ", 0) != std::string::npos) {
          // ストロークの returned_strokes への追加
        SPStroke stroke(line);
        this->returned_strokes.push_back(stroke);
      } else if (line.find(" delete: ", 0) != std::string::npos) {
          // キャンバスへストローク削除の通知
        this->canvas_should_be_refreshed = true;
      } else if (line != "" && line.find(" ", 0) == std::string::npos) {
          // キャンバスID一覧へキャンバスIDの追加
        this->canvas_list.push_back(line);
      }
    }
  }
  
    // 通信終了をキャンバスに通知
  NSNotification* notification =
  [NSNotification notificationWithName:@"SPServerResponseGot"
                                object:this->delegate];
  [[NSNotificationQueue defaultQueue] enqueueNotification:notification 
                                             postingStyle:NSPostWhenIdle];
    // 通知を通知キューに登録	
	dequeue_command();  // 実行に成功したコマンドを削除
	send_queued_command();  // 次のコマンドを送信
}

void StrokeSyncAgent::connectionDidFailWithError(void) {
  clear_connection();
}

@implementation StrokeSyncDelegate

- (void)connection:(NSURLConnection *)conn didReceiveData:(NSData *)data {
  std::string newstr((char *)[data bytes], [data length]);
  response += newstr;
}

- (void)connectionDidFinishLoading:(NSURLConnection *)conn {
  if (agent) {
    agent->connectionDidFinishLoading(response);
  }
  response = "";
}

- (void)connection:(NSURLConnection *)conn didFailWithError:(NSError *)error {
  if (agent) {
    agent->connectionDidFailWithError();
  }
  response = "";
}

@end


