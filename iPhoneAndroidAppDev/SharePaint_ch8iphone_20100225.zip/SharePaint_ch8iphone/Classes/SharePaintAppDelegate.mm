//
//  SharePaintAppDelegate.m
//  SharePaint
//
//  Created by Akira Suzuki on 10/02/23.
//  Copyright Akira Suzuki 2010. All rights reserved.
//

#import "SharePaintAppDelegate.h"
#import "SharePaintViewController.h"

@implementation SharePaintAppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
  [window addSubview:viewController.view];
  [window makeKeyAndVisible];
  
  SPCanvas* canvas = (SPCanvas*)viewController.view;
	[canvas loadDefaults];
	[canvas redrawStrokes:canvas->layer_bitmap];
}

- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}

- (void)applicationWillTerminate:(UIApplication *)application {
	SPCanvas* canvas = (SPCanvas*)viewController.view;
	[canvas saveDefaults];
}


@end
