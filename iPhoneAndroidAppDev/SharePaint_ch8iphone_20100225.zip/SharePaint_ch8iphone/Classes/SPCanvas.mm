//
//  SPCanvas.mm
//  SharePaint
//
//  Created by Akira Suzuki on 10/02/23.
//  Copyright 2010 Akira Suzuki. All rights reserved.
//

#import "SPCanvas.h"
#import "algorithm"
#import <sstream>


@implementation SPCanvas


- (id)initWithCoder:(NSCoder *)decoder {
  if (self = [super initWithCoder:decoder]) {
    self->prev_bitmap = NULL;
    [self setup];
  }
  return self;
}

- (void)setup {
  self->on_stroke = false;
  self->pen_properties = PenProperties();
  self->prev_bitmap = NULL;
  self->width = 320;
  self->height = 480;
  self->user_nickname = "iphone";
  self->canvas_id = "";
  self->user_id = "";
  self->InitServerTime = (long long)10000 * 365 * 24 * 60 * 60 * 1000;
  [self clear_canvas];
}

- (void)clear_canvas {
  if (self->stroke_bitmap)
    delete[] stroke_bitmap;
  if (self->display_bitmap)
    delete[] display_bitmap;
  if (self->prev_bitmap)
    delete[] prev_bitmap;
  for (int i = 0; i < SPLayerNumber; i ++)
    if (self->layer_bitmap[i])
      delete[] self->layer_bitmap[i];
  
  self->layer_index = 0;
  int length = self->width * self->height;
  for (unsigned int i = 0; i < SPLayerNumber; i ++)
    self->layer_bitmap[i] = new unsigned int[length];
  self->stroke_bitmap = new unsigned int[length];
  self->display_bitmap = new unsigned int[length];
  self->prev_bitmap = new unsigned int[length];
  for (int i = 0; i < length; i ++) {
    self->layer_bitmap[0][i] = 0xffffffff;
    self->layer_bitmap[1][i] = 0xffffffff;
    self->layer_bitmap[2][i] = 0xff000000;
    self->stroke_bitmap[i] = 0;
    self->display_bitmap[i] = 0xffffffff;
    self->prev_bitmap[i] = 0xffffffff;
  }

  [self setNeedsDisplay];
  
  self->sync_agent.canvas = self;
  [[NSNotificationCenter defaultCenter]
   addObserver:self 
   selector:@selector(get_response:)
   name:@"SPServerResponseGot"
   object:self->sync_agent.delegate];
  SPStroke stroke;
  stroke.user_name = [self userID];
  stroke.client_time = (long long)([[NSDate date] 
                                    timeIntervalSince1970] * 1000.0);
  self->sync_agent.append_stroke(stroke);
  self->sync_agent.get_strokes();
}


- (void)drawRect:(CGRect)rect {
  CGDataProviderRef providerref =
    CGDataProviderCreateWithData(NULL, self->display_bitmap + ((int)(rect.origin.y) * self->width + (int)(rect.origin.x)), rect.size.width * rect.size.height * 4, NULL);
  CGColorSpaceRef colorspace = CGColorSpaceCreateDeviceRGB();
  CGImageRef imgref =
  CGImageCreate(rect.size.width, rect.size.height, 8, 32, self->width * 4, colorspace, kCGImageAlphaPremultipliedFirst, providerref, NULL, NO, kCGRenderingIntentDefault);
  CGColorSpaceRelease(colorspace);
  CGDataProviderRelease(providerref);
  UIImage *img = [[UIImage alloc] initWithCGImage:imgref];
  [img drawInRect:rect];
  [img release];
  CGImageRelease(imgref);
}


- (void)dealloc {
  if (self->stroke_bitmap)
    delete[] stroke_bitmap;
  if (self->display_bitmap)
    delete[] display_bitmap;
  if (self->prev_bitmap)
    delete[] prev_bitmap;
  for (int i = 0; i < SPLayerNumber; i ++)
    if (self->layer_bitmap[i])
      delete[] self->layer_bitmap[i];
  [super dealloc];
}

- (void)touchPressedAtX:(int)x y:(int)y {
  if (self->draw_mode_button.selectedSegmentIndex == 1) {
    [self spuitAtX:x y:y];
    return;
  }  
  
  self->last_x = x;
  self->last_y = y;
  self->on_stroke = true;
  self->x_array.clear();
  self->y_array.clear();
  self->x_array.push_back(x);
  self->y_array.push_back(y);
}

- (void)touchDraggedAtX:(int)x y:(int)y {
  if (self->draw_mode_button.selectedSegmentIndex == 1) {
    [self spuitAtX:x y:y];
    return;
  }  
  
  [self drawLineFromX:self->last_x y:self->last_y toX:x y:y];
  
  int pen_width_half = self->pen_properties.width / 2 + 1;
  int min_x = std::min(x, self->last_x) - pen_width_half;
  int max_x = std::max(x, self->last_x) + pen_width_half;
  int min_y = std::min(y, self->last_y) - pen_width_half;
  int max_y = std::max(y, self->last_y) + pen_width_half;
  CGRect rect = CGRectMake(min_x, min_y,
                           max_x - min_x + 1, max_y - min_y + 1);
  [self composeBitmap:self->prev_bitmap with:self->stroke_bitmap alpha:(self->pen_properties.density / 255.0) to:self->layer_bitmap[self->layer_index] inRect:rect];
  [self composeAllLayers:self->layer_bitmap to:self->display_bitmap inRect:rect];
  [self setNeedsDisplayInRect:rect];
  self->last_x = x;
  self->last_y = y;
  self->x_array.push_back(x);
  self->y_array.push_back(y);
}

- (void)touchReleasedAtX:(int)x y:(int)y {
  if (self->draw_mode_button.selectedSegmentIndex == 1) {
    [self spuitEnded];
    return;
  }
  
  SPStroke stroke;
  stroke.user_name = [self userID];
  stroke.client_time = (long long)([[NSDate date] timeIntervalSince1970] * 1000);
  stroke.pen_properties = self->pen_properties;
  stroke.x_array = self->x_array;
  stroke.y_array = self->y_array;
 
  std::pair<long long, long long> times;
  times.first = InitServerTime;
  times.second = stroke.client_time;
  strokes_history[times] = stroke;

  self->on_stroke = false;
 
  [self get_response:nil];
  self->sync_agent.append_stroke(stroke);
  
  [self applyWithStrokeBitmap:self->prev_bitmap to:self->layer_bitmap[self->layer_index] alpha:(self->pen_properties.density / 255.0)];
}

- (void)drawLineFromX:(int)x0 y:(int)y0 toX:(int)x1 y:(int)y1 {
  CGColorSpaceRef colorspace = CGColorSpaceCreateDeviceRGB();
  CGContextRef context =
  CGBitmapContextCreate(self->stroke_bitmap, self->width, self->height, 8, self->width * 4, colorspace, kCGImageAlphaPremultipliedFirst);
  CGAffineTransform ctm = CGAffineTransformMakeScale(1, -1);
  ctm = CGAffineTransformTranslate(ctm, 0, - self->height);
  CGContextConcatCTM(context, ctm);
  
  CGContextSetLineCap(context, kCGLineCapRound);
  int pen_color = self->pen_properties.color;
  CGFloat components[4];
  components[0] = (pen_color & 0x00ff0000) / (255.0 * 0x10000);
  components[1] = (pen_color & 0x0000ff00) / (255.0 * 0x100);
  components[2] = (pen_color & 0x000000ff) / 255.0;
  components[3] = (pen_color & 0xff000000) / (255.0 * 0x1000000);
  CGColorRef color = CGColorCreate(colorspace, components);
  CGContextSetStrokeColorWithColor(context, color);
  CGContextSetLineWidth(context, self->pen_properties.width);
  
  CGContextMoveToPoint(context, x0, y0);
  CGContextAddLineToPoint(context, x1, y1);
  CGContextDrawPath(context, kCGPathStroke);
  
  CGColorSpaceRelease(colorspace);
  CGColorRelease(color);
  CGContextRelease(context);
}

- (void)drawStroke:(unsigned int*)bitmap with:(SPStroke)stroke {
  CGColorSpaceRef colorspace = CGColorSpaceCreateDeviceRGB();
  CGContextRef context =
  CGBitmapContextCreate(bitmap, self->width, self->height, 8, self->width * 4, colorspace, kCGImageAlphaPremultipliedFirst);
  CGAffineTransform ctm = CGAffineTransformMakeScale(1, -1);
  ctm = CGAffineTransformTranslate(ctm, 0, - self->height);
  CGContextConcatCTM(context, ctm);
  CGContextSetLineCap(context, kCGLineCapRound);
  CGContextSetLineJoin(context, kCGLineJoinRound);
  
  int pen_color = stroke.pen_properties.color;
  CGFloat components[4];
  components[0] = (pen_color & 0x00ff0000) / (255.0 * 0x10000);
  components[1] = (pen_color & 0x0000ff00) / (255.0 * 0x100);
  components[2] = (pen_color & 0x000000ff) / 255.0;
  components[3] = stroke.pen_properties.density / 255.0;
  CGColorRef color = CGColorCreate(colorspace, components);
  CGContextSetStrokeColorWithColor(context, color);
  CGContextSetLineWidth(context, stroke.pen_properties.width);
  
  CGContextMoveToPoint(context, stroke.x_array[0], stroke.y_array[0]);
  for (int i = 1; i < stroke.x_array.size(); i ++)
    CGContextAddLineToPoint(context, stroke.x_array[i], stroke.y_array[i]);
  CGContextDrawPath(context, kCGPathStroke);
  
  CGColorSpaceRelease(colorspace);
  CGColorRelease(color);
  CGContextRelease(context);
}

- (IBAction)undoOneStroke:(id)sender {
  if (self->strokes_history.empty()) return;
  
    // 自分自身の最後のストロークを検索
  std::map<std::pair<long long, long long>, SPStroke>::iterator it;
  it = self->strokes_history.end();
  do {
    it --;
    if (it->second.user_name == [self userID]) {  // もし見付かれば
      self->sync_agent.delete_stroke(it->second); // サーバへ報告
      self->strokes_history.erase(it);  // そのストロークを削除
      [self redrawStrokes:self->layer_bitmap];  // 描画しなおして
      return;  // 帰る
    }
  } while (it != self->strokes_history.begin());
}

- (std::string)canvasID {
  if (self->canvas_id == "") {
    NSDateFormatter *formatter = [[[NSDateFormatter alloc] init] autorelease];
    [formatter setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"GMT"]];
    [formatter setDateFormat:@"yyyyMMddHHmmssSSS"];
    NSString* nowstr = [formatter stringFromDate:[NSDate date]];
    std::string nowstr_([nowstr UTF8String]);
    self->canvas_id = self->user_nickname + "@" + nowstr_;
  }
  return self->canvas_id;
}

- (std::string)userID {
  if (self->user_id == "") {
    NSDateFormatter *formatter = [[[NSDateFormatter alloc] init] autorelease];
    [formatter setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"GMT"]];
    [formatter setDateFormat:@"yyyyMMddHHmmssSSS"];
    NSString* nowstr = [formatter stringFromDate:[NSDate date]];
    std::string nowstr_([nowstr UTF8String]);
    self->user_id = self->user_nickname + "@" + nowstr_;
  }
  return self->user_id;
}

- (void)redrawStrokes:(unsigned int*[])bitmaps {
  for (int i = 0; i < self->width * self->height; i ++) {
    bitmaps[0][i] = 0xffffffff;
    bitmaps[1][i] = 0xffffffff;
    bitmaps[2][i] = 0xff000000;
  }
  
  std::map<std::pair<long long, long long>, SPStroke>::iterator it
  = self->strokes_history.begin();
  int layer_i;
  while (it != self->strokes_history.end()) {
    layer_i = it->second.layer;
    if (layer_i < SPLayerNumber) 
      [self drawStroke:bitmaps[layer_i] with:it->second];
    it ++;
  }
  
  [self composeAllLayers:self->layer_bitmap to:self->display_bitmap inRect:CGRectMake(0, 0, self->width, self->height)];
  for (int i = 0; i < self->width * self->height; i ++) {
    self->stroke_bitmap[i] = 0;
    self->prev_bitmap[i] = bitmaps[self->layer_index][i];
  }
  [self setNeedsDisplay];
}

- (void)get_response:(NSNotification*)notification {
  bool should_be_refresh = false;
  std::vector<SPStroke>::iterator it;
  
  @synchronized (self->sync_agent.delegate) {
    switch (self->sync_agent.get_response()) {
      case StrokeSyncAgent::Strokes:
        it = self->sync_agent.returned_strokes.begin();
        while (it != self->sync_agent.returned_strokes.end()) {
          if ((*it).user_name == [self userID]) {
            std::pair<long long, long long> otimes;
            otimes.first = self->InitServerTime;
            otimes.second = (*it).client_time;
            self->strokes_history.erase(otimes);
          } else {
            should_be_refresh = true;
          }
          std::pair<long long, long long> ntimes;
          ntimes.first = it->server_time;
          ntimes.second = it->client_time;
          self->strokes_history[ntimes] = *it;
          it ++;
        }
        self->sync_agent.returned_strokes.clear();  // フラグをクリア
        if (should_be_refresh)
          [self redrawStrokes:self->layer_bitmap];
        break;
      case StrokeSyncAgent::Refresh:
        self->sync_agent.canvas_should_be_refreshed = false;  // フラグをクリア
        self->strokes_history.clear();
        self->sync_agent.get_strokes_sync();
    }
  }
}

- (void)composeBitmap:(unsigned int*)s_bitmap with:(unsigned int*)w_bitmap alpha:(CGFloat)density to:(unsigned int*)d_bitmap inRect:(CGRect)rect {
  CGColorSpaceRef colorspace = CGColorSpaceCreateDeviceRGB();
  CGContextRef context = 
  CGBitmapContextCreate(d_bitmap,
                        self->width, self->height, 8, 
                        self->width * 4, 
                        colorspace,
                        kCGImageAlphaPremultipliedFirst);
  CGColorSpaceRelease(colorspace);
  CGAffineTransform ctm = CGAffineTransformMakeScale(1, -1);
  ctm = CGAffineTransformTranslate(ctm, 0, - self->height);
  CGContextConcatCTM(context, ctm);
  UIGraphicsPushContext(context);
  
  if (s_bitmap != d_bitmap) {
    UIImage* s_img = [self clipImageOfBitmap:s_bitmap inRect:rect];
    [s_img drawAtPoint:rect.origin];
  }
  UIImage* w_img = [self clipImageOfBitmap:w_bitmap inRect:rect];
  [w_img drawAtPoint:rect.origin 
           blendMode:kCGBlendModeNormal alpha:density];
  
  UIGraphicsPopContext();
  CGContextRelease(context);
}

- (void)applyWithStrokeBitmap:(unsigned int*)s_bitmap to:(unsigned int*)d_bitmap alpha:(CGFloat)density {
  [self composeBitmap:s_bitmap with:self->stroke_bitmap 
                alpha:density
                   to:d_bitmap 
               inRect:CGRectMake(0, 0, self->width, self->height)];
  
  int len = self->width * self->height;
  for (int i = 0; i < len; i ++)
    self->stroke_bitmap[i] = 0;
  if (s_bitmap != d_bitmap)
    for (int i = 0; i < len; i ++)
      s_bitmap[i] = d_bitmap[i];
}

- (UIImage*)clipImageOfBitmap:(unsigned int*)bitmap inRect:(CGRect)rect {
  CGDataProviderRef providerref =
  CGDataProviderCreateWithData(NULL, 
                               bitmap + 
                               ((int)(rect.origin.y) * self->width  + (int)(rect.origin.x)), 
                               rect.size.width * rect.size.height * 4, NULL);
  CGColorSpaceRef colorspace = CGColorSpaceCreateDeviceRGB();
  CGImageRef imgref = 
  CGImageCreate(rect.size.width, rect.size.height, 8, 32,
                self->width  * 4, 
                colorspace,
                kCGImageAlphaPremultipliedFirst,
                providerref, NULL, NO, kCGRenderingIntentDefault);
  CGColorSpaceRelease(colorspace);
  CGDataProviderRelease(providerref);
  
  UIImage *img = [[[UIImage alloc] initWithCGImage:imgref] autorelease];
  CGImageRelease(imgref);
  return img;
}

- (void)composeAllLayers:(unsigned int*[])bitmaps to:(unsigned int*)bitmap inRect:(CGRect)rect {
	CGColorSpaceRef colorspace = CGColorSpaceCreateDeviceRGB();
  CGContextRef context = 
  CGBitmapContextCreate(bitmap,
                        self->width, self->height, 8, 
                        self->width * 4, 
                        colorspace,
                        kCGImageAlphaPremultipliedFirst);
  CGColorSpaceRelease(colorspace);
  CGAffineTransform ctm = CGAffineTransformMakeScale(1, -1);
  ctm = CGAffineTransformTranslate(ctm, 0, - self->height);
  CGContextConcatCTM(context, ctm);
  UIGraphicsPushContext(context);
	
	UIImage *layer_img[SPLayerNumber];
	for (unsigned int layer_i = 0; layer_i < SPLayerNumber; layer_i ++)
		layer_img[layer_i] = [self clipImageOfBitmap:bitmaps[layer_i]
                                          inRect:rect];
  [layer_img[0] drawAtPoint:rect.origin];
	[layer_img[1] drawAtPoint:rect.origin
									blendMode:kCGBlendModeMultiply
                      alpha:1.0];
	[layer_img[2] drawAtPoint:rect.origin
                  blendMode:kCGBlendModeScreen
                      alpha:1.0];
  
	UIGraphicsPopContext();
  CGContextRelease(context);
}

- (void)setLayerIndex:(unsigned int)index {
  self->layer_index = index;
  for (int i = 0; i < self->width * self->height; i ++) {
    self->stroke_bitmap[i] = 0;
    self->prev_bitmap[i] = self->layer_bitmap[index][i];
  }
}

- (void)spuitAtX:(int)x y:(int)y {
  unsigned int colint;
  colint = self->display_bitmap[y * self->width + x];
  unsigned int red, gre, blu;
  blu = (colint & 0xff000000) >> 24;
  gre = (colint & 0x00ff0000) >> 16;
  red = (colint & 0x0000ff00) >> 8;
  UIColor *col = [UIColor colorWithRed:red / 255.0
                                 green:gre / 255.0
                                  blue:blu / 255.0
                                 alpha:1.0];
  int y_ = y - self->spuit_view.bounds.size.height;
  self->spuit_view.backgroundColor = col;
  self->spuit_view.center = CGPointMake(x, y_);
  self->spuit_view.hidden = NO;
  self->pen_properties.color = 0xff000000 |
  (red << 16) | (gre << 8) | blu;
}

- (void)spuitEnded {
  self->spuit_view.hidden = YES;
  self->draw_mode_button.selectedSegmentIndex = 0;
}

- (void)setNickname:(std::string)nickname {
	if (self->user_nickname != nickname) {
		self->user_nickname = nickname;
		self->user_id = "";
	}
}

- (void)setCanvasID:(std::string)canvas_name {
	self->canvas_id = canvas_name;
	self->user_id = "";
	self->strokes_history.clear();
	self->sync_agent.get_strokes_sync();
	[self redrawStrokes:self->layer_bitmap];
	[self setInfoLabel];
}

- (void)setInfoLabel {
	std::ostringstream sstr;
	
	sstr << "layer:" << self->layer_index << " " << self->canvas_id;
	self->info_label.text 
  = [NSString stringWithUTF8String:sstr.str().c_str()];
  
}

- (void)saveDefaults {
	NSUserDefaults* defs = [NSUserDefaults standardUserDefaults];
	[defs setObject:
	 [NSString stringWithUTF8String:self->user_nickname.c_str()] 
					 forKey:@"UserNickname"];
	[defs setObject:self->search_bar.text
					 forKey:@"SearchNickname"];
	[defs setObject:
	 [NSString stringWithUTF8String:self->canvas_id.c_str()]
					 forKey:@"CanvasID"];
	
	NSMutableArray* strokearray = [NSMutableArray array];
	std::map<std::pair<long long, long long>, SPStroke>::iterator its;
	for (its = self->strokes_history.begin();
			 its != self->strokes_history.end(); its ++)
		[strokearray addObject:
		 [NSString stringWithUTF8String:(its->second).toString().c_str()]];
	[defs setObject:strokearray forKey:@"StrokesHistory"];
	
	NSMutableArray* queuearray = [NSMutableArray array];
	std::vector<std::string>::iterator itq;
	for (itq = self->sync_agent.queued_commands.begin(); 
			 itq != self->sync_agent.queued_commands.end(); itq ++)
		[queuearray addObject:
		 [NSString stringWithUTF8String:itq->c_str()]];
	[defs setObject:queuearray forKey:@"QueuedCommands"];
	
	[defs synchronize];
}

- (void)loadDefaults {
	NSUserDefaults* defs = [NSUserDefaults standardUserDefaults];
	NSString* str;
	str = [defs stringForKey:@"UserNickname"];
	if (str) self->user_nickname = [str UTF8String];
	self->search_bar.text 
  = [defs stringForKey:@"SearchNickname"];
	str = [defs stringForKey:@"CanvasID"];
	if (str) self->canvas_id = [str UTF8String];
	
	self->strokes_history.clear();
	NSArray* sarray = [defs arrayForKey:@"StrokesHistory"];
	if (sarray) 
		for (NSString* strokestr in sarray) {
			SPStroke stroke([strokestr UTF8String]);
			std::pair<long long, long long> times;
			times.first = stroke.server_time;
			times.second = stroke.client_time;
			self->strokes_history[times] = stroke;
		}
	
	self->sync_agent.queued_commands.clear();
	NSArray* qarray = [defs arrayForKey:@"QueuedCommands"];
	if (qarray)
		for (NSString* str in qarray)
			self->sync_agent.queued_commands.
			push_back(std::string([str UTF8String]));
}



@end
