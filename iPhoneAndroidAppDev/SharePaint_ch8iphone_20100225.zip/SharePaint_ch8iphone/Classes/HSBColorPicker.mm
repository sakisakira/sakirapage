//
//  HSBColorPicker.mm
//  SharePaint
//
//  Created by Akira Suzuki on 10/02/25.
//  Copyright 2010 Akira Suzuki. All rights reserved.
//

#import "HSBColorPicker.h"


@implementation HSBColorPicker
@end

	// HueLine
@implementation HueLine

- (void)drawRect:(CGRect)rect {
  int width = self.bounds.size.width;
  int height = self.bounds.size.height;
  
  for (int x = 0; x < width; x ++) {
    float hue = (float)x / width;
    UIColor *col = [[UIColor alloc] 
										initWithHue:hue 
                    saturation:1.0
                    brightness:1.0 
                    alpha:1.0];
		[col set];
		UIRectFill(CGRectMake(x, 0, 1, height));
		[col release];
	}
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
	UITouch *touch = [touches anyObject];
	if (touch) {
    CGPoint pt = [touch locationInView:self];
    float huevalue = pt.x / self.bounds.size.width;
    self->hue_slider.value = huevalue;
    [self->satbribox hueChanged:nil];
  }
}


@end

	// SatBriBox
@implementation SatBriBox
- (IBAction)hueChanged:(id)sender {
  [self setNeedsDisplay];
}

- (void)drawRect:(CGRect)rect {
  const float count = 50;
  float hue = self->hue_slider.value;
  float width = self.bounds.size.width;
  float height = self.bounds.size.height;
  float stepx = width / count;
  float stepy = height / count;
  for (float y = 0; y < height; y += stepy)
    for (float x = 0; x < width; x += stepx) {
      UIColor *col = [[UIColor alloc]
                      initWithHue:hue
                      saturation:(float)x / width
                      brightness:(float)y / height
                      alpha:1.0];
      [col set];
      UIRectFill(CGRectMake(x, y, stepx, stepy));
      [col release];
    }
}

- (void)touchAt:(CGPoint)pt {
  float width = self.bounds.size.width;
  float height = self.bounds.size.height;
  
	float hue = self->hue_slider.value;
	float sat = pt.x / width;
	float bri = pt.y / height;
	UIColor* col = [UIColor colorWithHue:hue
                            saturation:sat
                            brightness:bri
                                 alpha:1.0];
	self->pencolbox.backgroundColor = col;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
	UITouch *touch = [touches anyObject];
	if (touch) 
		[self touchAt:[touch locationInView:self]];
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
	UITouch *touch = [touches anyObject];
	if (touch) 
		[self touchAt:[touch locationInView:self]];
}

@end

