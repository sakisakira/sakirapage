package jp.co.paintsoft.sharepaint;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class SPCanvas extends View {
  int width, height;
  int last_x, last_y;
  boolean on_stroke;
  PenProperties pen_properties;
  Bitmap image_buffer;

  public SPCanvas(Context context, AttributeSet attrs) {
    super(context, attrs);
    setup();
  }
  
  void setup() {
    this.on_stroke = false;
    this.pen_properties = new PenProperties();
    this.image_buffer = null;
    this.width = 320;
    this.height = 480;
    clear_canvas();
  }
  
  void clear_canvas() {
    if (this.image_buffer != null)
      this.image_buffer.recycle();
    this.image_buffer = Bitmap.createBitmap(this.width, this.height, 
        Bitmap.Config.ARGB_8888);
    this.image_buffer.eraseColor(0xffffffff);
    invalidate();
  }
  
  @Override
  protected void onDraw(Canvas canvas) {
    super.onDraw(canvas);
    if (this.image_buffer != null) {
      canvas.drawBitmap(this.image_buffer, 0, 0, null);
    }
  }
  
  @Override
  public boolean onTouchEvent(MotionEvent event) {
    if (this.image_buffer == null)
      return false;
    int x = (int)event.getX();
    int y = (int)event.getY();
    
    switch (event.getAction()) {
    case MotionEvent.ACTION_DOWN:
      touchPressed(x, y);
      break;
    case MotionEvent.ACTION_MOVE:
      touchDragged(x, y);
      break;
    case MotionEvent.ACTION_UP:
      touchReleased(x, y);
      break;
    }
    return true;
  }
  
  void touchPressed(int x, int y) {
    this.last_x = x;
    this.last_y = y;
    this.on_stroke = true;
  }
  
  void touchDragged(int x, int y) {
    drawLine(this.last_x, this.last_y, x, y);
    int pen_width_half = this.pen_properties.width / 2 + 1;
    int min_x = Math.min(x, this.last_x) - pen_width_half;
    int max_x = Math.max(x, this.last_x) + pen_width_half;
    int min_y = Math.min(y, this.last_y) - pen_width_half;
    int max_y = Math.max(y, this.last_y) + pen_width_half;
    invalidate(new Rect(min_x, min_y, max_x, max_y));
    this.last_x = x;
    this.last_y = y;
  }
  
  void touchReleased(int x, int y) {
    this.on_stroke = false;
  }
  
  void drawLine(int x0, int y0, int x1, int y1) {
    Canvas canvas = new Canvas(this.image_buffer);
    Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    paint.setStrokeCap(Paint.Cap.ROUND);
    paint.setStrokeWidth(this.pen_properties.width);
    paint.setColor(this.pen_properties.color);
    canvas.drawLine(x0, y0, x1, y1, paint);
  }
}
