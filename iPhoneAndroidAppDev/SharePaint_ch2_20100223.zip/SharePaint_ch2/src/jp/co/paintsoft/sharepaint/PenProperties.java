package jp.co.paintsoft.sharepaint;

public class PenProperties {
  int color, width, density;
  
  PenProperties(int c, int w, int d) {
    this.color = c;
    this.width = w;
    this.density = d;
  }
  
  PenProperties() {
    this.color = 0xff000000;
    this.width = 3;
    this.density = 128;
  }

}
