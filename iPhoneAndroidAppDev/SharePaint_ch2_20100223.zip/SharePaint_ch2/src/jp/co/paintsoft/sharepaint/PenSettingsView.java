package jp.co.paintsoft.sharepaint;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.SeekBar;

public class PenSettingsView extends Activity {
  SeekBar pen_width_slider = null;
  RadioButton[] pen_color_btns = new RadioButton[5];

  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.pen_properties);
    pen_width_slider = (SeekBar)findViewById(R.id.pen_width);
    pen_color_btns[0] = (RadioButton)findViewById(R.id.pencolor_black);
    pen_color_btns[1] = (RadioButton)findViewById(R.id.pencolor_white);
    pen_color_btns[2] = (RadioButton)findViewById(R.id.pencolor_red);
    pen_color_btns[3] = (RadioButton)findViewById(R.id.pencolor_green);
    pen_color_btns[4] = (RadioButton)findViewById(R.id.pencolor_blue);
    int pen_width = getIntent().getIntExtra(SharePaint.PenWidthName, -1);
    if (pen_width >= 0)
      pen_width_slider.setProgress(pen_width);
    int pen_color = getIntent().getIntExtra(SharePaint.PenColorName, 0);
    if (pen_color != 0)
      setColorButton(pen_color);
    Button cancel_btn = (Button)findViewById(R.id.pen_prop_cancel);
    Button ok_btn = (Button)findViewById(R.id.pen_prop_ok);
    cancel_btn.setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        setResult(RESULT_CANCELED);
        finish();
      }});
    ok_btn.setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        okButtonPressed();
      }});
  }
  
  void setColorButton(int col) {
    if (col == 0xff000000)
      pen_color_btns[0].setChecked(true);
    else if (col == 0xffff0000)
      pen_color_btns[2].setChecked(true);
    else if (col == 0xff00ff00)
      pen_color_btns[3].setChecked(true);
    else if (col == 0xff0000ff)
      pen_color_btns[4].setChecked(true);
    else
      pen_color_btns[1].setChecked(true);
  }
  
  void okButtonPressed() {
    Intent intent = new Intent();
    int pencolor = 0;
    if (pen_color_btns[0].isChecked())
        pencolor = 0xff000000;
    else if (pen_color_btns[1].isChecked())
      pencolor = 0xffffffff;
    else if (pen_color_btns[2].isChecked())
      pencolor = 0xffff0000;
    else if (pen_color_btns[3].isChecked())
      pencolor = 0xff00ff00;
    else if (pen_color_btns[4].isChecked())
      pencolor = 0xff0000ff;
    if (pencolor != 0)
      intent.putExtra(SharePaint.PenColorName, pencolor);
    intent.putExtra(SharePaint.PenWidthName, 
        pen_width_slider.getProgress());
    setResult(RESULT_OK, intent);
    finish();
  }
}
