package jp.co.paintsoft.sharepaint;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SharePaint extends Activity {
  static final int ShowPenPropertiesId = 0;
  static final String PenWidthName = "PenWidth";
  static final String PenColorName = "PenColor";
  static SPCanvas canvas = null;
  
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.main);
    SharePaint.canvas = (SPCanvas)findViewById(R.id.sp_canvas);
    Button pen_prop_btn = (Button)findViewById(R.id.pen_prop_btn);
    pen_prop_btn.setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        Intent intent = new Intent(SharePaint.this, PenSettingsView.class);
        intent.putExtra(SharePaint.PenColorName,
            SharePaint.canvas.pen_properties.color);
        intent.putExtra(SharePaint.PenWidthName,
            SharePaint.canvas.pen_properties.width);
        startActivityForResult(intent,
            SharePaint.ShowPenPropertiesId);
      }});
  }
  
  @Override
  protected void onActivityResult(int reqid, int result, Intent intent) {
    if (reqid == ShowPenPropertiesId)
      if (result == RESULT_OK) {
        int pen_width = intent.getIntExtra(SharePaint.PenWidthName, -1);
        if (pen_width >= 0)
          SharePaint.canvas.pen_properties.width = pen_width;
        int pen_color = intent.getIntExtra(SharePaint.PenColorName, 0);
        if (pen_color != 0)
          SharePaint.canvas.pen_properties.color = pen_color;
      }
  }
}