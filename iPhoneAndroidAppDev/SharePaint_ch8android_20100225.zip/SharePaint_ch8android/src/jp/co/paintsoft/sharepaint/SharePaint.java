package jp.co.paintsoft.sharepaint;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.Iterator;

import jp.co.paintsoft.sharepaint.SPCanvas.Times;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

public class SharePaint extends Activity {
  static final int ShowPenPropertiesId = 0;
  static final int ShowHSBColorPickerId = 1;
  static final int ShowNicknameSearchId = 2;
  static final String PenWidthName = "PenWidth";
  static final String PenColorName = "PenColor";
  static final String PenDensityName = "PenDensity";
  static final String LayerIndexName = "LayerIndex";
  static final String StrokesHistoryFN ="StrokeHistory";
  static final String QueuedCommandsFN = "QueuedCommands";
  static SPCanvas canvas = null;
  
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.main);
    SharePaint.canvas = (SPCanvas)findViewById(R.id.sp_canvas);
    
    Spinner draw_mode =
      (Spinner) findViewById(R.id.draw_mode_choice);
    String[] choice_items = {"Draw", "Spuit"};
    ArrayAdapter<String> adapter =
      new ArrayAdapter<String>(this, 
          R.layout.draw_mode_choice_textview,
          choice_items);
    adapter.setDropDownViewResource(android.R.layout.select_dialog_item);
    draw_mode.setAdapter(adapter);
    draw_mode.setPrompt("Draw Mode");
    SharePaint.canvas.draw_mode_button = draw_mode;

    SharePaint.canvas.spuit_view = (View)findViewById(R.id.spuit_view);
    SharePaint.canvas.info_label =
      (TextView) findViewById(R.id.info_label);
    
    Button pen_prop_btn = (Button)findViewById(R.id.pen_prop_btn);
    pen_prop_btn.setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        Intent intent = new Intent(SharePaint.this, PenSettingsView.class);
        intent.putExtra(SharePaint.PenColorName,
            SharePaint.canvas.pen_properties.color);
        intent.putExtra(SharePaint.PenWidthName,
            SharePaint.canvas.pen_properties.width);
        intent.putExtra(SharePaint.PenDensityName, 
            SharePaint.canvas.pen_properties.density);
        intent.putExtra(SharePaint.LayerIndexName, 
            SharePaint.canvas.layer_index);
        startActivityForResult(intent,
            SharePaint.ShowPenPropertiesId);
      }});
    Button undo_btn = (Button)findViewById(R.id.undo_btn);
    undo_btn.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
        SharePaint.canvas.undoOneStroke();
      }});
    
    Button info_btn = (Button) findViewById(R.id.info_btn);
    info_btn.setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        NicknameSearch.user_nickname = SharePaint.canvas.user_nickname;
        Intent intent = new Intent(SharePaint.this,
            NicknameSearch.class);
        startActivityForResult(intent,
            SharePaint.ShowNicknameSearchId);
        }});

    restorePreferences();
    SharePaint.canvas.redrawStrokes(SharePaint.canvas.layer_bitmap);
  }
  
  @Override
  protected void onActivityResult(int reqid, int result, Intent intent) {
    if (reqid == ShowPenPropertiesId) {
      if (result == RESULT_OK) {
        int pen_width = intent.getIntExtra(SharePaint.PenWidthName, -1);
        if (pen_width >= 0)
          SharePaint.canvas.pen_properties.width = pen_width;
        int pen_density = intent.getIntExtra(SharePaint.PenDensityName, -1);
        if (pen_density >= 0)
          SharePaint.canvas.pen_properties.density = pen_density;
        int pen_color = intent.getIntExtra(SharePaint.PenColorName, 0);
        if (pen_color != 0)
          SharePaint.canvas.pen_properties.color = pen_color;
        int layer_index = intent.getIntExtra(SharePaint.LayerIndexName, -1);
        if (layer_index >= 0)
          SharePaint.canvas.setLayerIndex(layer_index);
      }
    } else if (reqid == ShowNicknameSearchId) {
        if (result == RESULT_OK) {
          SharePaint.canvas.setNickname(NicknameSearch.user_nickname);
        }
    }
  }
  
  @Override
  protected void onPause() {
    super.onPause();
    
    SharedPreferences pref = getPreferences(MODE_PRIVATE);
    SharedPreferences.Editor editor = pref.edit();
    editor.putString("UserNickname", canvas.user_nickname);
    editor.putString("SearchNickname", NicknameSearch.search_nickname);
    editor.putString("CanvasID", canvas.canvas_id);
    editor.commit();
    
    try {
      BufferedWriter writer;
      writer = new BufferedWriter(new OutputStreamWriter(
            openFileOutput(StrokesHistoryFN, MODE_PRIVATE)));
      Iterator<SPStroke> its = canvas.strokes_history.values().iterator();
      while (its.hasNext()) {
        String stroke_str = its.next().toString();
        writer.write(stroke_str, 0, stroke_str.length());
        writer.newLine();
      }
      writer.close();
      
      writer = new BufferedWriter(new OutputStreamWriter(
          openFileOutput(QueuedCommandsFN, MODE_PRIVATE)));
      Iterator<String> itq = canvas.sync_agent.queued_commands.iterator();
      while (itq.hasNext()) {
        String queue_str = itq.next();
        writer.write(queue_str, 0, queue_str.length());
        writer.newLine();
      }
      writer.close();
    } catch (IOException e) {
      Log.e("SharePaint", "onSaveInstanceState IOException");
      return;
    }
  }
  
  void restorePreferences() {
    SharedPreferences pref = getPreferences(MODE_PRIVATE);
    canvas.user_nickname = pref.getString("UserNickname", "public");
    NicknameSearch.search_nickname = pref.getString("SearchNickname", "");
    canvas.canvas_id = pref.getString("CanvasID", "");

    String[] flist = fileList();
    Arrays.sort(flist);
    if (Arrays.binarySearch(flist, StrokesHistoryFN) < 0 ||
        Arrays.binarySearch(flist, QueuedCommandsFN) < 0)
      return;

    try {
      BufferedReader reader;
      String line;
      
      canvas.strokes_history.clear();
      reader = new BufferedReader(new InputStreamReader(
          openFileInput(StrokesHistoryFN)));
      while ((line = reader.readLine()) != null) {
        SPStroke stroke = new SPStroke(line);
        Times t = canvas.new Times();
        t.client = stroke.client_time;
        t.server = stroke.server_time;
        if (t.client != 0 || t.server != 0)
          canvas.strokes_history.put(t, stroke);
      }
      reader.close();
      
      canvas.sync_agent.queued_commands.clear();
      reader = new BufferedReader(new InputStreamReader(
          openFileInput(QueuedCommandsFN)));
      while ((line = reader.readLine()) != null) {
        if (line.length() > 0)
          canvas.sync_agent.queued_commands.add(line);
      }
      reader.close();
    } catch (IOException e) {
      Log.e("SharePaint", "restorePreferences IOException");
    }
    
  }


}