package jp.co.paintsoft.sharepaint;

import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;
import java.util.TimeZone;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.Xfermode;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Spinner;
import android.widget.TextView;

public class SPCanvas extends View {
  static final long InitServerTime = (long)10000 * 365 * 24 * 60 * 60 * 1000;
  static final int SPLayerNumber = 3;
  int width, height;
  int last_x, last_y;
  boolean on_stroke;
  PenProperties pen_properties;
  TreeMap<Times, SPStroke> strokes_history;
  Vector<Integer> x_array, y_array;
  String user_nickname, canvas_id, user_id;
  StrokeSyncAgent sync_agent;
  int layer_index = 0;
  Bitmap stroke_bitmap = null;
  Bitmap display_bitmap = null;
  Bitmap prev_bitmap = null;
  Bitmap[] layer_bitmap = new Bitmap[SPLayerNumber];
  
  Spinner draw_mode_button;
  View spuit_view;
  TextView info_label;

  class Times implements Comparable<Times> {
    long server, client;

    public int compareTo(Times t2) {
      Times t1 = this;
      if (t1.server < t2.server)
        return -1;
      else if (t1.server > t2.server)
        return 1;
      else {
        if (t1.client < t2.client)
          return -1;
        else if (t1.client > t2.client)
          return 1;
      }
      return 0;
    }
    
    public boolean equals(Times t) {
      return (this.server == t.server) && (this.client == t.client);
    }
    
    @Override
    public boolean equals(Object o) {
      if (o instanceof Times) {
        Times t = (Times)o;
        return (this.server == t.server) && (this.client == t.client);
      }
      return (this == o);
    }
  }

  public SPCanvas(Context context, AttributeSet attrs) {
    super(context, attrs);
    setup();
  }
  
  void setup() {
    this.on_stroke = false;
    this.pen_properties = new PenProperties();
    this.width = 320;
    this.height = 480;
    this.strokes_history = new TreeMap<Times, SPStroke>();
    this.user_nickname = "android";
    this.canvas_id = "";
    this.user_id = "";
    this.sync_agent = new StrokeSyncAgent(this);
    this.x_array = this.y_array = null;
    clear_canvas();
  }
  
  void clear_canvas() {
    if (this.stroke_bitmap != null)
      this.stroke_bitmap.recycle();
    if (this.display_bitmap != null)
      this.display_bitmap.recycle();
    if (this.prev_bitmap != null)
      this.prev_bitmap.recycle();
    for (int i = 0; i < SPLayerNumber; i ++)
      if (this.layer_bitmap[i] != null)
        this.layer_bitmap[i].recycle();
    
    for (int i = 0; i < SPLayerNumber; i ++)
      this.layer_bitmap[i] = Bitmap.createBitmap(this.width, this.height, 
        Bitmap.Config.ARGB_8888);
    this.layer_bitmap[0].eraseColor(0xffffffff);
    this.layer_bitmap[1].eraseColor(0xffffffff);
    this.layer_bitmap[2].eraseColor(0xff000000);
    this.stroke_bitmap = Bitmap.createBitmap(this.width, this.height, 
        Bitmap.Config.ARGB_8888);
    this.stroke_bitmap.eraseColor(0);
    this.display_bitmap = Bitmap.createBitmap(this.width, this.height, 
        Bitmap.Config.ARGB_8888);
    this.display_bitmap.eraseColor(0xffffffff);
    this.prev_bitmap = Bitmap.createBitmap(this.width, this.height, 
        Bitmap.Config.ARGB_8888);
    this.prev_bitmap.eraseColor(0xffffffff);
    invalidate();
    
    SPStroke stroke = new SPStroke();
    stroke.user_name = userID();
    stroke.client_time = System.currentTimeMillis();
    stroke.pen_properties = new PenProperties();
    stroke.x_array = stroke.y_array = new Vector<Integer>();
    this.sync_agent.append_stroke(stroke);
    this.sync_agent.get_strokes();
  }
  
  @Override
  protected void onDraw(Canvas canvas) {
    super.onDraw(canvas);
    if (this.prev_bitmap != null) {
      canvas.drawBitmap(this.display_bitmap, 0, 0, null);
    }
  }
  
  @Override
  public boolean onTouchEvent(MotionEvent event) {
    if (this.prev_bitmap == null)
      return false;
    int x = (int)event.getX();
    int y = (int)event.getY();
    
    switch (event.getAction()) {
    case MotionEvent.ACTION_DOWN:
      touchPressed(x, y);
      break;
    case MotionEvent.ACTION_MOVE:
      touchDragged(x, y);
      break;
    case MotionEvent.ACTION_UP:
      touchReleased(x, y);
      break;
    }
    return true;
  }
  
  void touchPressed(int x, int y) {
    if (this.draw_mode_button.getSelectedItemPosition() == 1) {
      spuitAt(x, y);
      return;
    }
    
    this.last_x = x;
    this.last_y = y;
    this.on_stroke = true;
    this.x_array = new Vector<Integer>();
    this.y_array = new Vector<Integer>();
    this.x_array.add(x);
    this.y_array.add(y);
  }
  
  void touchDragged(int x, int y) {
    if (this.draw_mode_button.getSelectedItemPosition() == 1) {
      spuitAt(x, y);
      return;
    }

    drawLine(this.last_x, this.last_y, x, y);
    int pen_width_half = this.pen_properties.width / 2 + 1;
    int min_x = Math.min(x, this.last_x) - pen_width_half;
    int max_x = Math.max(x, this.last_x) + pen_width_half;
    int min_y = Math.min(y, this.last_y) - pen_width_half;
    int max_y = Math.max(y, this.last_y) + pen_width_half;
    Rect rect = new Rect(min_x, min_y, max_x, max_y);
    composeBitmap(this.prev_bitmap, this.stroke_bitmap, this.pen_properties.density, 
        this.layer_bitmap[this.layer_index], rect);
    composeAllLayers(this.layer_bitmap, this.display_bitmap, rect);
    invalidate(rect);
    this.last_x = x;
    this.last_y = y;
    this.x_array.add(x);
    this.y_array.add(y);
  }
  
  void touchReleased(int x, int y) {
    setInfoLabel();
    if (this.draw_mode_button.getSelectedItemPosition() == 1) {
      spuitEnded();
      return;
    }
    
    SPStroke stroke = new SPStroke();
    stroke.user_name = this.userID();
    stroke.client_time = System.currentTimeMillis();
    stroke.pen_properties = new PenProperties(this.pen_properties);
    stroke.x_array = this.x_array;
    stroke.y_array = this.y_array;
    Times times = new Times();
    times.server = SPCanvas.InitServerTime;
    times.client = stroke.client_time;
    strokes_history.put(times, stroke);
    this.x_array = this.y_array = null;
    
    this.on_stroke = false;
    get_response();
    this.sync_agent.append_stroke(stroke);
    
    applyWithStrokeBitmap(this.prev_bitmap, 
        this.layer_bitmap[this.layer_index], 
        this.pen_properties.density);
  }
  
  void drawLine(int x0, int y0, int x1, int y1) {
    Canvas canvas = new Canvas(this.stroke_bitmap);
    Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    paint.setStrokeCap(Paint.Cap.ROUND);
    paint.setStrokeWidth(this.pen_properties.width);
    paint.setColor(this.pen_properties.color);
    canvas.drawLine(x0, y0, x1, y1, paint);
  }
  
  public void drawStroke(Bitmap bitmap, SPStroke stroke) {
    if (stroke.x_array.size() == 0) return;
    Canvas canvas = new Canvas(bitmap);
    Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    paint.setStyle(Paint.Style.STROKE);
    paint.setStrokeCap(Paint.Cap.ROUND);
    paint.setStrokeJoin(Paint.Join.ROUND);
    paint.setStrokeWidth(stroke.pen_properties.width);
    paint.setColor(stroke.pen_properties.color);
    paint.setAlpha(stroke.pen_properties.density);
    Path path = new Path();
    path.moveTo(stroke.x_array.get(0), stroke.y_array.get(0));
    for (int i = 1; i < stroke.x_array.size(); i ++)
      path.lineTo(stroke.x_array.get(i),
          stroke.y_array.get(i));
    canvas.drawPath(path, paint);
  }
  
  public void undoOneStroke() {
    if (this.strokes_history.isEmpty()) return;  
    // �X�g���[�N���܂��������Ă��Ȃ���Ή������Ȃ�

    Set<Times> hist_times_set = this.strokes_history.keySet();
    // �~����TreeSet���쐬
    TreeSet<Times> hist_times = new TreeSet<Times>(new Comparator<Times>() {
      public int compare(Times t1, Times t2) {
        return -1 * t1.compareTo(t2);
      }});
    hist_times.addAll(hist_times_set);

    // �V�����X�g���[�N���猟��
    Iterator<Times> it = hist_times.iterator();
    while (it.hasNext()) {
      Times times = it.next();
      SPStroke stroke = this.strokes_history.get(times);
      if (stroke.user_name.equals(userID())) {
        // ���������̃X�g���[�N�����t��������
        this.sync_agent.delete_stroke(stroke);
        // �X�g���[�N�폜���T�[�o�֒ʒm����
        this.strokes_history.remove(times);  // ������폜����
        redrawStrokes(this.layer_bitmap);  // �ĕ`�悵��
        return;  // �A��
      }
    }
  }
  
  public String canvasID() {
    if (this.canvas_id.length() == 0) {
      SimpleDateFormat date_format;
      date_format = new SimpleDateFormat("yyyyMMddHHmmssSSS");
      date_format.setTimeZone(TimeZone.getTimeZone("GMT"));
      this.canvas_id = this.user_nickname + "@" + date_format.format(new Date());
    }
    return this.canvas_id;
  }
  
  public String userID() {
    if (this.user_id.length() == 0) {
      SimpleDateFormat date_format;
      date_format = new SimpleDateFormat("yyyyMMddHHmmssSSS");
      date_format.setTimeZone(TimeZone.getTimeZone("GMT"));
      this.user_id = this.user_nickname + "@" + date_format.format(new Date());
    }
    return this.user_id;
  }
  
  public void redrawStrokes(Bitmap[] bitmaps) {
    bitmaps[0].eraseColor(0xffffffff);
    bitmaps[1].eraseColor(0xffffffff);
    bitmaps[2].eraseColor(0xff000000);
    
    Set<Times> hist_times = this.strokes_history.keySet();
        //  �X�g���[�N�����������S�����̏W�����擾
    Iterator<Times> it = hist_times.iterator();
    SPStroke stroke;
    while (it.hasNext()) {
      stroke = strokes_history.get(it.next());
      if (stroke.layer < bitmaps.length)
        drawStroke(bitmaps[stroke.layer], stroke);
    }

    composeAllLayers(this.layer_bitmap, this.display_bitmap,
        new Rect(0, 0, this.width - 1, this.height - 1));
    Canvas canvas = new Canvas(this.prev_bitmap);
    canvas.drawBitmap(bitmaps[this.layer_index], 0, 0, null);
    this.stroke_bitmap.eraseColor(0);
    invalidate();
  }
  
  public void get_response() {
    boolean should_be_refresh = false;  // �L�����o�X�ĕ`��t���O
    Iterator<SPStroke> it;
      // �X�g���[�N�p�̃C�e���[�^��錾 
    
    synchronized (this.sync_agent.returned_strokes) {
    switch (this.sync_agent.get_response()) {
    case StrokeSyncAgent.Strokes: // �����X�g���[�N�������
        it = this.sync_agent.returned_strokes.iterator();
        while (it.hasNext()) {
          SPStroke stroke = it.next();
          if (stroke.user_name.equals(userID())) {
            Times otimes = new Times();
            otimes.server = SPCanvas.InitServerTime;
            otimes.client = stroke.client_time;
            this.strokes_history.remove(otimes);
          } else {
            should_be_refresh = true;
          }
          Times ntimes = new Times();
          ntimes.server = stroke.server_time;
          ntimes.client = stroke.client_time;
          this.strokes_history.put(ntimes, stroke);
        }
        // �T�[�o����߂��Ă����S�X�g���[�N�̏������I��������
        this.sync_agent.returned_strokes.clear();
        if (should_be_refresh) // �����L�����o�X�X�V�t���O�������Ă����
          redrawStrokes(this.layer_bitmap);
        break;
      case StrokeSyncAgent.Refresh:
        this.sync_agent.canvas_should_be_refreshed = false; // �t���O���N���A
        this.strokes_history.clear(); // �X�g���[�N����j��
        this.sync_agent.get_strokes();
      }
    }
  }

  void composeBitmap(Bitmap s_bitmap, Bitmap w_bitmap, 
      int density, Bitmap d_bitmap, Rect rect) {
    Canvas canvas = new Canvas(d_bitmap);
    if (s_bitmap != d_bitmap)
      canvas.drawBitmap(s_bitmap, rect, rect, null);
    Paint paint = new Paint();
    paint.setAlpha(density);
    canvas.drawBitmap(w_bitmap, rect, rect, paint);
  }

  void applyWithStrokeBitmap(Bitmap s_bitmap, Bitmap d_bitmap, int density) {
    composeBitmap(s_bitmap, this.stroke_bitmap, density, d_bitmap,
        new Rect(0, 0, this.width - 1, this.height - 1));
    this.stroke_bitmap.eraseColor(0);
    if (s_bitmap != d_bitmap) {
      Canvas canvas = new Canvas(s_bitmap);
      canvas.drawBitmap(d_bitmap, 0, 0, null);
    }
  }

  void composeAllLayers(Bitmap[] bitmaps, Bitmap bitmap, Rect rect) {
    Canvas canvas = new Canvas(bitmap);
    canvas.drawBitmap(bitmaps[0], rect, rect, null);
    Paint paint = new Paint();
    Xfermode mult_xfer = 
      new PorterDuffXfermode(PorterDuff.Mode.MULTIPLY);
    paint.setXfermode(mult_xfer);
    canvas.drawBitmap(bitmaps[1], rect, rect, paint);
    Xfermode screen_xfer = 
      new PorterDuffXfermode(PorterDuff.Mode.SCREEN);
    paint.setXfermode(screen_xfer);
    canvas.drawBitmap(bitmaps[2], rect, rect, paint);
  }

  public void setLayerIndex(int index) {
    this.layer_index = index;  // ���݂̃��C���[�ԍ���ݒ�
    this.stroke_bitmap.eraseColor(0);  // �X�g���[�N�p�r�b�g�}�b�v�͓�����
    Canvas canvas = new Canvas(this.prev_bitmap);  // �X�g���[�N�O�摜�ɂ�
    canvas.drawBitmap(this.layer_bitmap[index], 0, 0, null);
          // �I���������C���[�̉摜��`��
    setInfoLabel();
  }

  void spuitAt(int x, int y) {
    int colint;
    colint = this.display_bitmap.getPixel(x, y);
    int w = this.spuit_view.getWidth();
    int h = this.spuit_view.getHeight();
    int y_ = y - h * 3 / 2;
    int x_ = x- w / 2;
    this.spuit_view.setBackgroundColor(colint);
    this.spuit_view.layout(x_, y_, x_ + w, y_ + h);
    this.spuit_view.setVisibility(VISIBLE);
    this.pen_properties.color = colint;
  }
  
  void spuitEnded() {
    this.spuit_view.setVisibility(INVISIBLE);
    this.draw_mode_button.setSelection(0);
  }

  void setNickname(String nickname) {
    if (!this.user_nickname.equals(nickname)) {
      this.user_nickname = nickname;
      this.user_id = "";
    }
  }
  
  void setCanvasID(String canvas_id) {
    this.canvas_id = canvas_id;
    this.user_id = "";
    this.strokes_history.clear();
    this.sync_agent.get_strokes_sync();
    redrawStrokes(this.layer_bitmap);
    setInfoLabel();
  }
  
  void setInfoLabel() {
    this.info_label.setText("layer:" + this.layer_index + " " + this.canvas_id);
  }

}
