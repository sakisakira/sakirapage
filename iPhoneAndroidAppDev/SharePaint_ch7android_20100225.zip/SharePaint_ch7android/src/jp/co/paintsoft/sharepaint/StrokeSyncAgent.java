package jp.co.paintsoft.sharepaint;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Date;
import java.util.Vector;

import android.os.Handler;
import android.util.Log;

public class StrokeSyncAgent {
  static final String ServerURL = "http://sharepaintserver.appspot.com/";
  static final long timeout = 10 * 1000;  // �^�C���A�E�g��10�b
  
  HTTPConnectDelegate connection;  // �T�[�o�Ƃ̔񓯊��ʐM
  boolean requesting;  // �ʐM�����ǂ���
  long last_request_time;  // �Ō�ɃT�[�o�֑��M��������
  
  static final int None = 0;
  static final int Strokes = 1;
  static final int Refresh = 2;
  
  Vector<String> queued_commands;
  Vector<SPStroke> returned_strokes;
  boolean canvas_should_be_refreshed;
  Vector<String> canvas_list;
  
  Handler handler;
  SPCanvas canvas;
  
  public StrokeSyncAgent(SPCanvas canvas) {
    this.canvas = canvas;
    this.handler = new Handler();
    this.connection = null;
    this.requesting = false;
    this.last_request_time = 0;
    this.queued_commands = new Vector<String>();
    this.returned_strokes = new Vector<SPStroke>();
    this.canvas_should_be_refreshed = false;
    this.canvas_list = new Vector<String>();
  }
  
  void send_command(String cmd, boolean synchronous) {
    if (synchronous) {
      HTTPConnectDelegate connect;
      connect = new HTTPConnectDelegate(null, this);
      String[] strs = connect.send_command_and_get_response(cmd);
      if (strs != null)
        connect.connectionDidFinishLoading(strs);
    } else {
      this.connection = new HTTPConnectDelegate(cmd, this);
      this.requesting = true;
      this.last_request_time = new Date().getTime();
      this.connection.start();  // �ʂ̃X���b�h�Őڑ�
    }
  }
  
  void queue_command(String cmd) {
    synchronized (this.queued_commands) {
      this.queued_commands.add(cmd);  // �L���[�̖����ɃR�}���h��ǉ�
    }
    
    if (this.requesting) {  // �������̃R�}���h�𑗐M���Ȃ��
      if (this.last_request_time + StrokeSyncAgent.timeout <
          new Date().getTime()) {   // �����^�C���A�E�g���Ă����
        this.connection.http_connect.disconnect(); // �����ڑ�����
        clear_connection();  // ��n��������
      } else {
        return;
      }
    }
    
    // ���̃R�}���h�̑��M���łȂ����(�A�C�h����ԂȂ�)
    send_queued_command();  // �L���[�ɓ����Ă���R�}���h�𑗐M
  }
  
  void dequeue_command() {
    synchronized (this.queued_commands) {
      if (!this.queued_commands.isEmpty())
        this.queued_commands.remove(0);
    }
  }
  
  void send_queued_command() {
    synchronized (this.queued_commands) {
      if (!this.queued_commands.isEmpty())
        send_command(this.queued_commands.get(0), false);
    }
  }
  
  public void append_stroke(SPStroke stroke) {
    String cmd = this.canvas.canvasID() + ": append: " + stroke.toString();
    queue_command(cmd);
  }
  
  public void delete_stroke(SPStroke stroke) {
    stroke.x_array.clear();  // ���_���W(X���W)���폜
    stroke.y_array.clear();  // ���_���W(Y���W)���폜
    String cmd = this.canvas.canvasID() + ": delete: " + stroke.toString();
    queue_command(cmd);
  }
  
  public void get_strokes() {
    String cmd = this.canvas.canvasID() + ": get_strokes: ";
    queue_command(cmd);
  }
  
  public void get_strokes_sync() {
    String cmd = this.canvas.canvasID() + ": get_strokes: ";
    send_command(cmd, true);
  }
  
  public void search_canvas_list(String nickname) {
    String cmd = this.canvas.canvasID() + 
    ": search_canvas_list: nickname:" + nickname;
    send_command(cmd, true);  // �����ʐM�ŃR�}���h���M
  }
  
  public int get_response() {
    if (this.canvas_should_be_refreshed)
      return Refresh;
    else if (!this.returned_strokes.isEmpty())
      return Strokes;
    else
      return None;
  }

  void clear_connection() {
    if (this.connection != null) 
      this.connection.http_connect.disconnect();
    this.connection = null;
    this.requesting = false;
    this.last_request_time = 0;
  }
  

  
  // HTTPConnectDelegate
  class HTTPConnectDelegate extends Thread {
    HttpURLConnection http_connect;
    StrokeSyncAgent agent;
    String command;
    
    HTTPConnectDelegate(String cmd, StrokeSyncAgent agent) {
      super();
      this.command = cmd;
      this.agent = agent;
    }
    
    String[] send_command_and_get_response(String cmd) {
      Vector<String> response = new Vector<String>();
      try {
        URL url = new URL(StrokeSyncAgent.ServerURL);
        this.http_connect = (HttpURLConnection)url.openConnection();
        this.http_connect.setUseCaches(false);
        this.http_connect.setRequestMethod("POST");
        this.http_connect.setReadTimeout((int) StrokeSyncAgent.timeout);
        this.http_connect.setDoInput(true);
        this.http_connect.setDoOutput(true);
        this.http_connect.connect();
        PrintStream writer =
          new PrintStream(this.http_connect.getOutputStream());
        writer.print(cmd);
        writer.flush();
        writer.close();

        InputStreamReader reader =
          new InputStreamReader(this.http_connect.getInputStream());
        BufferedReader buf_reader =
          new BufferedReader(reader);
        String line;
        while ((line = buf_reader.readLine()) != null) {
          response.add(line);
          Log.i("SharePaint", "response:" + line);
        }
        buf_reader.close();
        reader.close();
      } catch (Exception e) {
        this.http_connect.disconnect();
        return null;
      }
      
      return response.toArray(new String[0]);
    }
    
    public void run() {
      String[] response;
      response = send_command_and_get_response(this.command);
      if (response == null)
        connectionDidFailWithError();
      else
        connectionDidFinishLoading(response);
    }
    
    void connectionDidFinishLoading(String[] strs) {
      int line_num;
      String line;
      
      agent.clear_connection();  // �ڑ����\�[�X���N���A
      
      synchronized (agent.returned_strokes) {
        for (line_num = 0; line_num < strs.length; line_num ++) {
          line = strs[line_num];
          if (line.contains(" append: ")) {
            SPStroke stroke = new SPStroke(line);
            this.agent.returned_strokes.add(stroke);
          } else if (line.contains(" delete: ")) {
            this.agent.canvas_should_be_refreshed = true;
          } else if (!line.contains(" ") && line.length() > 0) {
            this.agent.canvas_list.add(line.trim());
          }
        }
      }
      
      agent.handler.post(new Runnable() {
        public void run () {
          agent.canvas.get_response();
        }});
      agent.dequeue_command();  // ���s�ɐ��������R�}���h���폜
      agent.send_queued_command();  // ���̃R�}���h�𑗐M
    }
    
    void connectionDidFailWithError() {
      agent.clear_connection();
    }
  }
}

