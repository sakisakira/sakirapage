package jp.co.paintsoft.sharepaint;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;

public class HSBColorPicker extends Activity {
  static int pen_color;
  
    @Override
    public void onCreate(Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      setContentView(R.layout.hsb_color_picker);
      
      SeekBar hue_slider = (SeekBar)findViewById(R.id.hue_slider);
      SatBriBox sat_bri_box = (SatBriBox)findViewById(R.id.sat_bri_box);
      hue_slider.setOnSeekBarChangeListener(sat_bri_box);
      sat_bri_box.pencolbox = (View)findViewById(R.id.hsb_pencolbox);
      
      int pen_color = getIntent().getIntExtra(SharePaint.PenColorName, 0);
      if (pen_color != 0) {
        float[] hsv = new float[3];
        Color.colorToHSV(pen_color, hsv);
        hue_slider.setProgress((int)hsv[0]);
        sat_bri_box.hue = (int)hsv[0];
        sat_bri_box.pencolbox.setBackgroundColor(pen_color);
        HSBColorPicker.pen_color = pen_color;
      }
      
      Button cancel_btn = (Button)findViewById(R.id.hsb_picker_cancel);
      Button ok_btn = (Button)findViewById(R.id.hsb_picker_ok);
      cancel_btn.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
          setResult(RESULT_CANCELED);
          finish();
        }});
      ok_btn.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
          Intent intent = new Intent();
          intent.putExtra(SharePaint.PenColorName,
              HSBColorPicker.pen_color);
          setResult(RESULT_OK, intent);
          finish();
        }});      
    }
}
