package jp.co.paintsoft.sharepaint;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

public class SharePaint extends Activity {
  static final int ShowPenPropertiesId = 0;
  static final int ShowHSBColorPickerId = 1;
  static final String PenWidthName = "PenWidth";
  static final String PenColorName = "PenColor";
  static final String PenDensityName = "PenDensity";
  static final String LayerIndexName = "LayerIndex";
  static SPCanvas canvas = null;
  
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.main);
    SharePaint.canvas = (SPCanvas)findViewById(R.id.sp_canvas);
    
    Spinner draw_mode =
      (Spinner) findViewById(R.id.draw_mode_choice);
    String[] choice_items = {"Draw", "Spuit"};
    ArrayAdapter<String> adapter =
      new ArrayAdapter<String>(this, 
          R.layout.draw_mode_choice_textview,
          choice_items);
    adapter.setDropDownViewResource(android.R.layout.select_dialog_item);
    draw_mode.setAdapter(adapter);
    draw_mode.setPrompt("Draw Mode");
    SharePaint.canvas.draw_mode_button = draw_mode;

    SharePaint.canvas.spuit_view = (View)findViewById(R.id.spuit_view);
    
    Button pen_prop_btn = (Button)findViewById(R.id.pen_prop_btn);
    pen_prop_btn.setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        Intent intent = new Intent(SharePaint.this, PenSettingsView.class);
        intent.putExtra(SharePaint.PenColorName,
            SharePaint.canvas.pen_properties.color);
        intent.putExtra(SharePaint.PenWidthName,
            SharePaint.canvas.pen_properties.width);
        intent.putExtra(SharePaint.PenDensityName, 
            SharePaint.canvas.pen_properties.density);
        intent.putExtra(SharePaint.LayerIndexName, 
            SharePaint.canvas.layer_index);
        startActivityForResult(intent,
            SharePaint.ShowPenPropertiesId);
      }});
    Button undo_btn = (Button)findViewById(R.id.undo_btn);
    undo_btn.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
        SharePaint.canvas.undoOneStroke();
      }});
  }
  
  @Override
  protected void onActivityResult(int reqid, int result, Intent intent) {
    if (reqid == ShowPenPropertiesId)
      if (result == RESULT_OK) {
        int pen_width = intent.getIntExtra(SharePaint.PenWidthName, -1);
        if (pen_width >= 0)
          SharePaint.canvas.pen_properties.width = pen_width;
        int pen_density = intent.getIntExtra(SharePaint.PenDensityName, -1);
        if (pen_density >= 0)
          SharePaint.canvas.pen_properties.density = pen_density;
        int pen_color = intent.getIntExtra(SharePaint.PenColorName, 0);
        if (pen_color != 0)
          SharePaint.canvas.pen_properties.color = pen_color;
        int layer_index = intent.getIntExtra(SharePaint.LayerIndexName, -1);
        if (layer_index >= 0)
          SharePaint.canvas.setLayerIndex(layer_index);
      }
  }
}